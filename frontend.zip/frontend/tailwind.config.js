/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          950: '#030712',
          900: '#070f26',
          850: '#0b1536',
          800: '#101d4a',
          700: '#1a2c6d',
          600: '#263e94'
        },
        gold: {
          50: '#fffbeb',
          100: '#fef3c7',
          200: '#fde68a',
          300: '#fcd34d',
          400: '#fbbf24',
          500: '#f59e0b',
          600: '#d97706',
          700: '#b45309',
          800: '#92400e'
        }
      },
      boxShadow: {
        'gold-glow': '0 0 20px -3px rgba(245, 158, 11, 0.35)',
        'gold-glow-lg': '0 0 30px -2px rgba(245, 158, 11, 0.5)',
        'blue-glow': '0 0 25px -4px rgba(37, 99, 235, 0.4)',
      }
    },
  },
  plugins: [],
}

