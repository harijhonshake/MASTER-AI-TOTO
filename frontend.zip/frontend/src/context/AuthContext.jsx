import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [favourites, setFavourites] = useState([]);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const token = localStorage.getItem('toto_ai_token');
    if (!token) {
      setLoading(false);
      return;
    }

    try {
      const res = await api.getMe();
      if (res.success && res.user) {
        setUser(res.user);
        loadFavourites();
      } else {
        localStorage.removeItem('toto_ai_token');
        setUser(null);
      }
    } catch (e) {
      localStorage.removeItem('toto_ai_token');
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  const loadFavourites = async () => {
    try {
      const res = await api.getFavourites();
      if (res.success) {
        setFavourites(res.favourites || []);
      }
    } catch (e) {
      console.error('Failed to load favourites:', e);
    }
  };

  const login = async (email, password) => {
    const res = await api.login(email, password);
    if (res.success && res.token) {
      localStorage.setItem('toto_ai_token', res.token);
      setUser(res.user);
      loadFavourites();
      return { success: true };
    }
    return { success: false, error: res.error || 'Login failed' };
  };

  const register = async (name, email, password) => {
    const res = await api.register(name, email, password);
    if (res.success && res.token) {
      localStorage.setItem('toto_ai_token', res.token);
      setUser(res.user);
      loadFavourites();
      return { success: true };
    }
    return { success: false, error: res.error || 'Registration failed' };
  };

  const logout = () => {
    localStorage.removeItem('toto_ai_token');
    setUser(null);
    setFavourites([]);
  };

  const addFavourite = async (type, numbers, label, notes) => {
    if (!user) return { success: false, error: 'Please sign in to save favourites.' };
    const res = await api.saveFavourite(type, numbers, label, notes);
    if (res.success) {
      loadFavourites();
    }
    return res;
  };

  const removeFavourite = async (id) => {
    const res = await api.deleteFavourite(id);
    if (res.success) {
      setFavourites(prev => prev.filter(f => f._id !== id));
    }
    return res;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        favourites,
        login,
        register,
        logout,
        addFavourite,
        removeFavourite,
        refreshFavourites: loadFavourites,
        isAdmin: user?.role === 'admin'
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}

