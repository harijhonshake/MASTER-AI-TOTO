const API_BASE = '/api';

function getHeaders() {
  const token = localStorage.getItem('toto_ai_token');
  const headers = { 'Content-Type': 'application/json' };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

export const api = {
  // TOTO
  getTotoLatest: async () => {
    const res = await fetch(`${API_BASE}/toto/latest`);
    return res.json();
  },
  getTotoHistory: async (page = 1, limit = 15, search = '') => {
    const res = await fetch(`${API_BASE}/toto/history?page=${page}&limit=${limit}&search=${encodeURIComponent(search)}`);
    return res.json();
  },
  getTotoStats: async () => {
    const res = await fetch(`${API_BASE}/toto/stats`);
    return res.json();
  },
  checkTotoNumbers: async (numbers) => {
    const res = await fetch(`${API_BASE}/toto/check`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ numbers })
    });
    return res.json();
  },

  // 4D
  getFourDLatest: async () => {
    const res = await fetch(`${API_BASE}/fourd/latest`);
    return res.json();
  },
  getFourDHistory: async (page = 1, limit = 15, search = '') => {
    const res = await fetch(`${API_BASE}/fourd/history?page=${page}&limit=${limit}&search=${encodeURIComponent(search)}`);
    return res.json();
  },
  getFourDStats: async () => {
    const res = await fetch(`${API_BASE}/fourd/stats`);
    return res.json();
  },
  checkFourDNumber: async (number) => {
    const res = await fetch(`${API_BASE}/fourd/check`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ number })
    });
    return res.json();
  },

  // AI Generators
  generateToto: async (mode = 'ai_statistical', count = 1, favourites = []) => {
    const res = await fetch(`${API_BASE}/ai/generate/toto`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode, count, favourites })
    });
    return res.json();
  },
  generateFourD: async (mode = 'ai_statistical', count = 1, favourite = '') => {
    const res = await fetch(`${API_BASE}/ai/generate/4d`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ mode, count, favourite })
    });
    return res.json();
  },
  getAiReport: async () => {
    const res = await fetch(`${API_BASE}/ai/report`);
    return res.json();
  },

  // Auth & Favourites
  login: async (email, password) => {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    return res.json();
  },
  register: async (name, email, password) => {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password })
    });
    return res.json();
  },
  getMe: async () => {
    const res = await fetch(`${API_BASE}/auth/me`, { headers: getHeaders() });
    return res.json();
  },
  getFavourites: async () => {
    const res = await fetch(`${API_BASE}/auth/favourites`, { headers: getHeaders() });
    return res.json();
  },
  saveFavourite: async (type, numbers, label, notes) => {
    const res = await fetch(`${API_BASE}/auth/favourites`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ type, numbers, label, notes })
    });
    return res.json();
  },
  deleteFavourite: async (id) => {
    const res = await fetch(`${API_BASE}/auth/favourites/${id}`, {
      method: 'DELETE',
      headers: getHeaders()
    });
    return res.json();
  },

  // Admin
  adminCreateToto: async (data) => {
    const res = await fetch(`${API_BASE}/admin/toto`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(data)
    });
    return res.json();
  },
  adminUpdateToto: async (id, data) => {
    const res = await fetch(`${API_BASE}/admin/toto/${id}`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify(data)
    });
    return res.json();
  },
  adminDeleteToto: async (id) => {
    const res = await fetch(`${API_BASE}/admin/toto/${id}`, {
      method: 'DELETE',
      headers: getHeaders()
    });
    return res.json();
  },
  adminCreateFourD: async (data) => {
    const res = await fetch(`${API_BASE}/admin/4d`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify(data)
    });
    return res.json();
  },
  adminUpdateFourD: async (id, data) => {
    const res = await fetch(`${API_BASE}/admin/4d/${id}`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify(data)
    });
    return res.json();
  },
  adminDeleteFourD: async (id) => {
    const res = await fetch(`${API_BASE}/admin/4d/${id}`, {
      method: 'DELETE',
      headers: getHeaders()
    });
    return res.json();
  },
  adminTriggerSync: async () => {
    const res = await fetch(`${API_BASE}/admin/sync`, {
      method: 'POST',
      headers: getHeaders()
    });
    return res.json();
  },
  adminImportData: async (type, records) => {
    const res = await fetch(`${API_BASE}/admin/import`, {
      method: 'POST',
      headers: getHeaders(),
      body: JSON.stringify({ type, records })
    });
    return res.json();
  },
  adminGetUsers: async () => {
    const res = await fetch(`${API_BASE}/admin/users`, { headers: getHeaders() });
    return res.json();
  },
  adminUpdateUserRole: async (id, role) => {
    const res = await fetch(`${API_BASE}/admin/users/${id}/role`, {
      method: 'PUT',
      headers: getHeaders(),
      body: JSON.stringify({ role })
    });
    return res.json();
  },
  adminGetAnalytics: async () => {
    const res = await fetch(`${API_BASE}/admin/analytics`, { headers: getHeaders() });
    return res.json();
  }
};

