import React, { useState, useEffect } from 'react';
import { 
  Bar, 
  Doughnut 
} from 'react-chartjs-2';
import { 
  BarChart3, 
  TrendingUp, 
  PieChart, 
  Layers, 
  Hash, 
  Binary, 
  Sparkles, 
  Info,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';
import { api } from '../services/api';

export default function FourDAnalysis() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedPosition, setSelectedPosition] = useState('thousandsFirstDigit'); // thousandsFirstDigit, hundredsSecondDigit, tensThirdDigit, unitsLastDigit

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    setLoading(true);
    try {
      const res = await api.getFourDStats();
      if (res.success) {
        setStats(res);
      }
    } catch (e) {
      console.error('Failed to load 4D stats:', e);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !stats) {
    return (
      <div className="py-20 flex flex-col items-center justify-center gap-3">
        <div className="w-10 h-10 border-4 border-gold-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-sm font-semibold text-slate-300">Computing 4D Multi-Position AI Analytics...</p>
      </div>
    );
  }

  // 1. Chart: Patterns Breakdown (ABCD, AABC, AABB, AAAB, AAAA)
  const patternKeys = Object.keys(stats.patterns);
  const patternChartData = {
    labels: patternKeys.map(k => `${k} (${stats.patterns[k].actualPct}%)`),
    datasets: [
      {
        data: patternKeys.map(k => stats.patterns[k].count),
        backgroundColor: [
          '#3b82f6', // ABCD - Single
          '#f59e0b', // AABC - Double
          '#8b5cf6', // AABB - Double Pair
          '#ec4899', // AAAB - Triple
          '#10b981'  // AAAA - Quad
        ],
        borderWidth: 0
      }
    ]
  };

  // 2. Chart: Digit Position Frequency (0 to 9)
  const posLabels = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const posData = posLabels.map(d => stats.digitPositions[selectedPosition]?.[parseInt(d)] || 0);

  const positionChartData = {
    labels: posLabels,
    datasets: [
      {
        label: `Frequency of Digit in ${selectedPosition}`,
        data: posData,
        backgroundColor: '#f59e0b',
        borderColor: '#d97706',
        borderWidth: 1,
        borderRadius: 4
      }
    ]
  };

  // 3. Chart: Top Front Pairs & Back Pairs
  const topFrontPairs = stats.pairsAnalysis?.topFrontPairs?.slice(0, 8) || [];
  const pairsChartData = {
    labels: topFrontPairs.map(p => p.pair),
    datasets: [
      {
        label: 'Front Pair Occurrences',
        data: topFrontPairs.map(p => p.count),
        backgroundColor: '#06b6d4',
        borderRadius: 4
      }
    ]
  };

  const positionTitles = {
    thousandsFirstDigit: '1st Digit (Thousands - First Digit)',
    hundredsSecondDigit: '2nd Digit (Hundreds)',
    tensThirdDigit: '3rd Digit (Tens)',
    unitsLastDigit: '4th Digit (Units - Last Digit)'
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Title & Info Banner */}
      <div className="bg-navy-900 border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
              <Binary className="w-6 h-6 text-gold-400" />
              Singapore 4D AI Mathematical Analysis
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              23 Winning Prizes Per Draw
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Evaluated {stats.totalPrizesDrawn} winning numbers across {stats.totalDraws} verified draws (1st, 2nd, 3rd, 10 Starters, 10 Consolations).
          </p>
        </div>

        <div className="bg-navy-950/80 border border-gold-500/30 rounded-xl p-3 flex items-center gap-3">
          <Info className="w-5 h-5 text-gold-400 flex-shrink-0" />
          <div className="text-[11px] text-slate-300 leading-tight">
            <span className="font-bold text-gold-300">Combinatorial Space: 10,000 Numbers</span>
            <div className="text-slate-400 text-[10px]">Range 0000 to 9999 with uniform random drawing.</div>
          </div>
        </div>
      </div>

      {/* 1. DIGIT PATTERN BREAKDOWN & SEQUENCE ANALYSIS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Pattern Doughnut Chart */}
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
              <PieChart className="w-4 h-4 text-gold-400" />
              Repeated Digit Pattern Breakdown
            </h3>
            <p className="text-[11px] text-slate-400 mb-4">
              ABCD (Single), AABC (Double), AABB (Double Pair), AAAB (Triple), AAAA (Quad).
            </p>
            <div className="h-56 flex items-center justify-center">
              <Doughnut 
                data={patternChartData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { position: 'right', labels: { color: '#cbd5e1', font: { size: 10 } } }
                  }
                }}
              />
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-800/80 space-y-1.5 text-[11px]">
            <div className="flex items-center justify-between text-slate-300">
              <span>Single (ABCD):</span>
              <span className="font-mono font-bold text-blue-400">{stats.patterns.ABCD.actualPct}% (Theory: 50.4%)</span>
            </div>
            <div className="flex items-center justify-between text-slate-300">
              <span>Double (AABC):</span>
              <span className="font-mono font-bold text-amber-400">{stats.patterns.AABC.actualPct}% (Theory: 43.2%)</span>
            </div>
            <div className="flex items-center justify-between text-slate-300">
              <span>Double Pair (AABB):</span>
              <span className="font-mono font-bold text-purple-400">{stats.patterns.AABB.actualPct}% (Theory: 2.7%)</span>
            </div>
          </div>
        </div>

        {/* Position Digit Frequency Chart */}
        <div className="lg:col-span-2 bg-navy-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-gold-400" />
                  Position Digit Frequency (0 to 9)
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  Currently viewing: <strong className="text-gold-300">{positionTitles[selectedPosition]}</strong>
                </p>
              </div>

              {/* Position Switcher */}
              <div className="flex items-center gap-1 bg-navy-950 p-1 rounded-xl border border-slate-800 text-[11px]">
                <button
                  onClick={() => setSelectedPosition('thousandsFirstDigit')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    selectedPosition === 'thousandsFirstDigit' ? 'bg-gold-500 text-navy-950 shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  1st Digit
                </button>
                <button
                  onClick={() => setSelectedPosition('hundredsSecondDigit')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    selectedPosition === 'hundredsSecondDigit' ? 'bg-gold-500 text-navy-950 shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  2nd Digit
                </button>
                <button
                  onClick={() => setSelectedPosition('tensThirdDigit')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    selectedPosition === 'tensThirdDigit' ? 'bg-gold-500 text-navy-950 shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  3rd Digit
                </button>
                <button
                  onClick={() => setSelectedPosition('unitsLastDigit')}
                  className={`px-2.5 py-1 rounded-lg font-bold transition-all ${
                    selectedPosition === 'unitsLastDigit' ? 'bg-gold-500 text-navy-950 shadow-sm' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  4th Digit (Last)
                </button>
              </div>
            </div>

            <div className="h-56">
              <Bar 
                data={positionChartData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                  scales: {
                    x: { ticks: { color: '#94a3b8', font: { size: 11, weight: 'bold' } } },
                    y: { ticks: { color: '#94a3b8', font: { size: 10 } } }
                  }
                }}
              />
            </div>
          </div>

          <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Theoretical uniform frequency: 10% per digit</span>
            <span>Total Digits in Position: {posData.reduce((a, b) => a + b, 0)}</span>
          </div>
        </div>

      </div>

      {/* 2. FIRST DIGIT & LAST DIGIT ANALYSIS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* First Digit Deep Dive */}
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Hash className="w-4 h-4 text-gold-400" />
              First Digit Analysis (Thousands: 0_ _ _ to 9_ _ _)
            </h4>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Leading digit breakdown for all prizes vs 1st Prize specifically.
          </p>

          <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
            {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((d) => (
              <div key={d} className="bg-navy-950 p-2 rounded-xl border border-slate-800 text-center">
                <span className="text-base font-black text-gold-400 font-mono">{d}</span>
                <div className="text-[11px] font-bold text-white mt-1">
                  {stats.firstDigitAnalysis?.distribution[d] || 0}
                </div>
                <div className="text-[9px] text-slate-500">all</div>
                <div className="text-[10px] font-bold text-amber-300 mt-1">
                  {stats.firstDigitAnalysis?.firstPrizeFirstDigit[d] || 0}
                </div>
                <div className="text-[9px] text-slate-500">1st Pz</div>
              </div>
            ))}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-300 flex items-center justify-between">
            <span>Most Frequent 1st Digit: <strong className="text-gold-400">{stats.firstDigitAnalysis?.mostFrequent}</strong></span>
            <span>Least Frequent: <strong className="text-slate-400">{stats.firstDigitAnalysis?.leastFrequent}</strong></span>
          </div>
        </div>

        {/* Last Digit Deep Dive */}
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <Hash className="w-4 h-4 text-cyan-400" />
              Last Digit Analysis (Units: _ _ _0 to _ _ _9)
            </h4>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            Ending digit breakdown for all prizes vs 1st Prize specifically.
          </p>

          <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
            {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((d) => (
              <div key={d} className="bg-navy-950 p-2 rounded-xl border border-slate-800 text-center">
                <span className="text-base font-black text-cyan-400 font-mono">{d}</span>
                <div className="text-[11px] font-bold text-white mt-1">
                  {stats.lastDigitAnalysis?.distribution[d] || 0}
                </div>
                <div className="text-[9px] text-slate-500">all</div>
                <div className="text-[10px] font-bold text-cyan-300 mt-1">
                  {stats.lastDigitAnalysis?.firstPrizeLastDigit[d] || 0}
                </div>
                <div className="text-[9px] text-slate-500">1st Pz</div>
              </div>
            ))}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-xs text-slate-300 flex items-center justify-between">
            <span>Most Frequent Last Digit: <strong className="text-cyan-400">{stats.lastDigitAnalysis?.mostFrequent}</strong></span>
            <span>Least Frequent: <strong className="text-slate-400">{stats.lastDigitAnalysis?.leastFrequent}</strong></span>
          </div>
        </div>

      </div>

      {/* 3. PAIR NUMBER ANALYSIS & MOST FREQUENT 4D NUMBERS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Top Front & Back Pairs */}
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
          <h4 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
            <Sparkles className="w-4 h-4 text-gold-400" />
            Top Pair Number Analysis (00 to 99)
          </h4>
          <p className="text-xs text-slate-400 mb-4">
            Most frequent two-digit front pairs (digits 1&2) and back pairs (digits 3&4).
          </p>

          <div className="grid grid-cols-2 gap-4">
            
            {/* Front Pairs */}
            <div>
              <span className="text-xs font-bold text-cyan-300 uppercase tracking-wider block mb-2">
                Top Front Pairs
              </span>
              <div className="space-y-1.5">
                {stats.pairsAnalysis?.topFrontPairs?.slice(0, 5).map((p, i) => (
                  <div key={i} className="flex items-center justify-between bg-navy-950 px-3 py-1.5 rounded-lg border border-slate-800 text-xs">
                    <span className="font-mono font-bold text-gold-300">{p.pair}_ _</span>
                    <span className="font-mono text-slate-400">{p.count} hits</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Back Pairs */}
            <div>
              <span className="text-xs font-bold text-gold-300 uppercase tracking-wider block mb-2">
                Top Back Pairs
              </span>
              <div className="space-y-1.5">
                {stats.pairsAnalysis?.topBackPairs?.slice(0, 5).map((p, i) => (
                  <div key={i} className="flex items-center justify-between bg-navy-950 px-3 py-1.5 rounded-lg border border-slate-800 text-xs">
                    <span className="font-mono font-bold text-cyan-300">_ _{p.pair}</span>
                    <span className="font-mono text-slate-400">{p.count} hits</span>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </div>

        {/* Sequence Analysis & Most Frequent 4D Numbers */}
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-purple-400" />
              Number Sequence & Run Analysis
            </h4>
            <p className="text-xs text-slate-400 mb-4">
              Consecutive and partial run occurrences across all drawn numbers.
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
              {Object.keys(stats.sequenceAnalysis).map((seqKey) => {
                const item = stats.sequenceAnalysis[seqKey];
                return (
                  <div key={seqKey} className="bg-navy-950 p-2.5 rounded-xl border border-slate-800 text-center">
                    <div className="text-[10px] text-slate-400 font-bold uppercase truncate" title={seqKey}>
                      {seqKey.replace('_', ' ')}
                    </div>
                    <div className="text-base font-mono font-black text-white mt-1">
                      {item.count}
                    </div>
                    <div className="text-[10px] text-gold-400 font-semibold">
                      {item.pct}%
                    </div>
                  </div>
                );
              })}
            </div>

            <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
              Most Drawn 4D Numbers in History
            </span>
            <div className="flex flex-wrap gap-2">
              {stats.mostFrequentOverall?.slice(0, 8).map((item) => (
                <div key={item.number} className="bg-navy-950 px-3 py-1.5 rounded-lg border border-gold-500/30 flex items-center gap-2 text-xs">
                  <span className="font-mono font-black text-gold-400">{item.number}</span>
                  <span className="text-slate-400 text-[10px]">({item.count}x)</span>
                </div>
              ))}
            </div>
          </div>

          <p className="text-[10px] text-slate-500 mt-3 border-t border-slate-800 pt-2">
            💡 Full 4-digit consecutive runs (e.g. 1234 or 9876) represent less than 0.2% of draws.
          </p>
        </div>

      </div>

    </div>
  );
}

