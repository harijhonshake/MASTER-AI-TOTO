import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  Plus, 
  Trash2, 
  Edit3, 
  RefreshCw, 
  Upload, 
  Users, 
  Activity, 
  CheckCircle, 
  AlertTriangle,
  Server,
  Layers,
  Database
} from 'lucide-react';
import { api } from '../services/api';

export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState('toto'); // toto, 4d, sync, users, analytics
  const [analytics, setAnalytics] = useState(null);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  // TOTO Form State
  const [totoForm, setTotoForm] = useState({
    drawNumber: '',
    drawDate: '',
    winningNumbers: '',
    additionalNumber: '',
    jackpot: 1000000,
    isCascade: false
  });

  // 4D Form State
  const [fourDForm, setFourDForm] = useState({
    drawNumber: '',
    drawDate: '',
    firstPrize: '',
    secondPrize: '',
    thirdPrize: '',
    starterPrizes: '',
    consolationPrizes: ''
  });

  // Bulk Import State
  const [importType, setImportType] = useState('toto');
  const [importJson, setImportJson] = useState('');

  useEffect(() => {
    loadAdminData();
  }, [activeTab]);

  const loadAdminData = async () => {
    setLoading(true);
    setMessage('');
    setErrorMessage('');
    try {
      if (activeTab === 'users') {
        const res = await api.adminGetUsers();
        if (res.success) setUsers(res.users);
      } else if (activeTab === 'analytics' || activeTab === 'sync') {
        const res = await api.adminGetAnalytics();
        if (res.success) setAnalytics(res);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // Submit TOTO Draw
  const handleCreateToto = async (e) => {
    e.preventDefault();
    setMessage('');
    setErrorMessage('');
    try {
      const winNums = totoForm.winningNumbers.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n));
      const res = await api.adminCreateToto({
        ...totoForm,
        winningNumbers: winNums,
        additionalNumber: parseInt(totoForm.additionalNumber)
      });
      if (res.success) {
        setMessage(`Successfully created TOTO Draw #${totoForm.drawNumber}`);
        setTotoForm({
          drawNumber: '',
          drawDate: '',
          winningNumbers: '',
          additionalNumber: '',
          jackpot: 1000000,
          isCascade: false
        });
      } else {
        setErrorMessage(res.error || 'Failed to create TOTO draw');
      }
    } catch (err) {
      setErrorMessage(err.message);
    }
  };

  // Submit 4D Draw
  const handleCreateFourD = async (e) => {
    e.preventDefault();
    setMessage('');
    setErrorMessage('');
    try {
      const starters = fourDForm.starterPrizes.split(',').map(s => s.trim()).filter(Boolean);
      const consolations = fourDForm.consolationPrizes.split(',').map(s => s.trim()).filter(Boolean);

      const res = await api.adminCreateFourD({
        ...fourDForm,
        starterPrizes: starters,
        consolationPrizes: consolations
      });
      if (res.success) {
        setMessage(`Successfully created 4D Draw #${fourDForm.drawNumber}`);
        setFourDForm({
          drawNumber: '',
          drawDate: '',
          firstPrize: '',
          secondPrize: '',
          thirdPrize: '',
          starterPrizes: '',
          consolationPrizes: ''
        });
      } else {
        setErrorMessage(res.error || 'Failed to create 4D draw');
      }
    } catch (err) {
      setErrorMessage(err.message);
    }
  };

  // Trigger Sync
  const handleTriggerSync = async () => {
    setLoading(true);
    setMessage('');
    setErrorMessage('');
    try {
      const res = await api.adminTriggerSync();
      if (res.success) {
        setMessage(`Singapore Pools Live Sync Completed: TOTO updated: ${res.result?.report?.totoUpdated || 0}, 4D updated: ${res.result?.report?.fourDUpdated || 0}`);
        loadAdminData();
      } else {
        setErrorMessage(res.error || 'Sync failed');
      }
    } catch (err) {
      setErrorMessage(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Bulk Import
  const handleBulkImport = async () => {
    setLoading(true);
    setMessage('');
    setErrorMessage('');
    try {
      const parsed = JSON.parse(importJson);
      if (!Array.isArray(parsed)) {
        throw new Error('Import data must be a JSON array of draw objects.');
      }
      const res = await api.adminImportData(importType, parsed);
      if (res.success) {
        setMessage(`Import Success! ${res.imported} records inserted, ${res.skipped} existing records preserved.`);
        setImportJson('');
      } else {
        setErrorMessage(res.error || 'Import failed');
      }
    } catch (err) {
      setErrorMessage(`Invalid JSON: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Update User Role
  const handleToggleUserRole = async (user) => {
    const newRole = user.role === 'admin' ? 'user' : 'admin';
    try {
      const res = await api.adminUpdateUserRole(user.id, newRole);
      if (res.success) {
        setUsers(users.map(u => u.id === user.id ? { ...u, role: newRole } : u));
      }
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-amber-950 via-navy-900 to-navy-900 border border-gold-500/40 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-gold-500 text-navy-950 font-black">
              <ShieldAlert className="w-5 h-5" />
            </span>
            <h2 className="text-2xl font-black text-white tracking-tight">
              TOTO AI MASTER Administration Hub
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Authoritative results database management, verified draw insertions, data synchronization & system audit trail.
          </p>
        </div>

        {/* Global Action: Trigger Sync */}
        <button
          onClick={handleTriggerSync}
          disabled={loading}
          className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-gold-500 to-amber-600 hover:from-gold-400 hover:to-amber-500 text-navy-950 font-extrabold text-xs shadow-gold-glow transition-all"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          <span>Trigger Live Sync Now</span>
        </button>
      </div>

      {/* Status Notifications */}
      {message && (
        <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/40 text-emerald-300 font-semibold text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4" />
          <span>{message}</span>
        </div>
      )}
      {errorMessage && (
        <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/40 text-rose-300 font-semibold text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Admin Tabs */}
      <div className="flex border-b border-slate-800 bg-navy-900 p-1.5 rounded-xl gap-2 overflow-x-auto text-xs">
        {[
          { id: 'toto', label: 'TOTO Management', icon: Plus },
          { id: '4d', label: '4D Management', icon: Plus },
          { id: 'sync', label: 'Data Sync & Import', icon: Upload },
          { id: 'users', label: 'User Directory', icon: Users },
          { id: 'analytics', label: 'System Analytics & Logs', icon: Activity }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-gold-500 text-navy-950 shadow-sm'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: TOTO RESULTS MANAGEMENT */}
      {activeTab === 'toto' && (
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Plus className="w-4 h-4 text-gold-400" />
            Add Verified Singapore TOTO Draw Record
          </h3>
          <p className="text-xs text-slate-400">
            Prevents duplicate draw records automatically. Winning numbers must be 6 unique integers (1-49) and 1 additional number.
          </p>

          <form onSubmit={handleCreateToto} className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-2">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Draw Number</label>
              <input
                type="number"
                required
                placeholder="e.g. 4051"
                value={totoForm.drawNumber}
                onChange={e => setTotoForm({ ...totoForm, drawNumber: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-white focus:outline-none focus:border-gold-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Draw Date</label>
              <input
                type="date"
                required
                value={totoForm.drawDate}
                onChange={e => setTotoForm({ ...totoForm, drawDate: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-white focus:outline-none focus:border-gold-500"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-slate-300 font-semibold mb-1">6 Winning Numbers (comma-separated)</label>
              <input
                type="text"
                required
                placeholder="e.g. 5, 12, 19, 23, 34, 45"
                value={totoForm.winningNumbers}
                onChange={e => setTotoForm({ ...totoForm, winningNumbers: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-white focus:outline-none focus:border-gold-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Additional Number (1-49)</label>
              <input
                type="number"
                min={1}
                max={49}
                required
                placeholder="e.g. 8"
                value={totoForm.additionalNumber}
                onChange={e => setTotoForm({ ...totoForm, additionalNumber: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-white focus:outline-none focus:border-gold-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Estimated Jackpot (SGD)</label>
              <input
                type="number"
                required
                placeholder="e.g. 1000000"
                value={totoForm.jackpot}
                onChange={e => setTotoForm({ ...totoForm, jackpot: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-white focus:outline-none focus:border-gold-500"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <input
                type="checkbox"
                id="isCascade"
                checked={totoForm.isCascade}
                onChange={e => setTotoForm({ ...totoForm, isCascade: e.target.checked })}
                className="w-4 h-4 rounded text-gold-500 bg-navy-950 border-slate-700"
              />
              <label htmlFor="isCascade" className="text-slate-300 font-medium">Cascade / Hong Bao Draw</label>
            </div>

            <div className="md:col-span-2 pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gold-500 hover:bg-gold-400 text-navy-950 font-bold text-xs uppercase tracking-wider shadow-gold-glow transition-all"
              >
                Insert & Verify TOTO Draw
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 2: 4D RESULTS MANAGEMENT */}
      {activeTab === '4d' && (
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Plus className="w-4 h-4 text-gold-400" />
            Add Verified Singapore 4D Draw Record
          </h3>
          <p className="text-xs text-slate-400">
            Records 1st, 2nd, 3rd, 10 starter, and 10 consolation numbers.
          </p>

          <form onSubmit={handleCreateFourD} className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs pt-2">
            <div>
              <label className="block text-slate-300 font-semibold mb-1">Draw Number</label>
              <input
                type="number"
                required
                placeholder="e.g. 5321"
                value={fourDForm.drawNumber}
                onChange={e => setFourDForm({ ...fourDForm, drawNumber: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-white focus:outline-none focus:border-gold-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">Draw Date</label>
              <input
                type="date"
                required
                value={fourDForm.drawDate}
                onChange={e => setFourDForm({ ...fourDForm, drawDate: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-white focus:outline-none focus:border-gold-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">1st Prize (4 Digits)</label>
              <input
                type="text"
                required
                maxLength={4}
                placeholder="e.g. 4812"
                value={fourDForm.firstPrize}
                onChange={e => setFourDForm({ ...fourDForm, firstPrize: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-gold-300 font-mono font-bold focus:outline-none focus:border-gold-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">2nd Prize (4 Digits)</label>
              <input
                type="text"
                required
                maxLength={4}
                placeholder="e.g. 0932"
                value={fourDForm.secondPrize}
                onChange={e => setFourDForm({ ...fourDForm, secondPrize: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-white font-mono font-bold focus:outline-none focus:border-gold-500"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold mb-1">3rd Prize (4 Digits)</label>
              <input
                type="text"
                required
                maxLength={4}
                placeholder="e.g. 7183"
                value={fourDForm.thirdPrize}
                onChange={e => setFourDForm({ ...fourDForm, thirdPrize: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-white font-mono font-bold focus:outline-none focus:border-gold-500"
              />
            </div>

            <div className="md:col-span-3">
              <label className="block text-slate-300 font-semibold mb-1">10 Starter Numbers (comma-separated)</label>
              <input
                type="text"
                placeholder="e.g. 1123, 4452, 9812, 0014, 5521, 6723, 8829, 3410, 1928, 5412"
                value={fourDForm.starterPrizes}
                onChange={e => setFourDForm({ ...fourDForm, starterPrizes: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-gold-500"
              />
            </div>

            <div className="md:col-span-3">
              <label className="block text-slate-300 font-semibold mb-1">10 Consolation Numbers (comma-separated)</label>
              <input
                type="text"
                placeholder="e.g. 8831, 0192, 4519, 3910, 9912, 6512, 3318, 7129, 0194, 7621"
                value={fourDForm.consolationPrizes}
                onChange={e => setFourDForm({ ...fourDForm, consolationPrizes: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-navy-950 border border-slate-700 text-white font-mono text-xs focus:outline-none focus:border-gold-500"
              />
            </div>

            <div className="md:col-span-3 pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gold-500 hover:bg-gold-400 text-navy-950 font-bold text-xs uppercase tracking-wider shadow-gold-glow transition-all"
              >
                Insert & Verify 4D Draw
              </button>
            </div>
          </form>
        </div>
      )}

      {/* TAB 3: DATA SYNC & BULK IMPORT */}
      {activeTab === 'sync' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Automated Sync Status Card */}
          <div className="bg-navy-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-gold-400" />
              Singapore Pools Auto-Sync Service
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Background workers periodically poll verified Singapore Pools draw schedules (Mondays/Thursdays for TOTO; Wednesdays/Saturdays/Sundays for 4D). Duplicate draw prevention ensures database idempotency.
            </p>

            <div className="p-4 rounded-xl bg-navy-950 border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between text-slate-300">
                <span>Auto-Sync Frequency:</span>
                <span className="font-mono text-gold-300 font-bold">Hourly (3,600s)</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Last Synchronized:</span>
                <span className="font-mono text-slate-400">{analytics?.stats?.lastSync || 'Active'}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Database Connection:</span>
                <span className="text-emerald-400 font-bold">Verified Resilient Storage</span>
              </div>
            </div>

            <button
              onClick={handleTriggerSync}
              disabled={loading}
              className="w-full py-3 rounded-xl bg-gold-500 hover:bg-gold-400 text-navy-950 font-bold text-xs uppercase tracking-wider shadow-gold-glow transition-all"
            >
              {loading ? 'Polling Service...' : 'Run Sync Immediately'}
            </button>
          </div>

          {/* Bulk JSON Import Card */}
          <div className="bg-navy-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Upload className="w-4 h-4 text-cyan-400" />
              Bulk Historical Data Importer
            </h3>
            <p className="text-xs text-slate-400">
              Paste an array of raw JSON draw objects to perform idempotent historical backfill.
            </p>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400">Target Lottery:</span>
              <button
                type="button"
                onClick={() => setImportType('toto')}
                className={`px-3 py-1 rounded-lg text-xs font-bold ${
                  importType === 'toto' ? 'bg-gold-500 text-navy-950' : 'bg-slate-800 text-slate-400'
                }`}
              >
                TOTO
              </button>
              <button
                type="button"
                onClick={() => setImportType('4d')}
                className={`px-3 py-1 rounded-lg text-xs font-bold ${
                  importType === '4d' ? 'bg-gold-500 text-navy-950' : 'bg-slate-800 text-slate-400'
                }`}
              >
                4D
              </button>
            </div>

            <textarea
              rows={5}
              placeholder='[{"drawNumber": 4055, "drawDate": "2026-11-20", "winningNumbers": [3, 14, 22, 29, 38, 44], "additionalNumber": 10}]'
              value={importJson}
              onChange={e => setImportJson(e.target.value)}
              className="w-full p-3 rounded-xl bg-navy-950 border border-slate-700 font-mono text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-gold-500"
            />

            <button
              onClick={handleBulkImport}
              disabled={loading || !importJson.trim()}
              className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 font-bold text-xs uppercase transition-all"
            >
              Parse & Import Dataset
            </button>
          </div>

        </div>
      )}

      {/* TAB 4: USER DIRECTORY */}
      {activeTab === 'users' && (
        <div className="bg-navy-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="p-5 border-b border-slate-800">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Users className="w-4 h-4 text-gold-400" />
              Registered User Directory & Roles
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Manage permissions and administrative grants.
            </p>
          </div>

          <table className="w-full text-left text-xs">
            <thead className="bg-navy-950 text-slate-400 uppercase font-semibold text-[11px] border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">User</th>
                <th className="py-3 px-4">Email</th>
                <th className="py-3 px-4">Registered</th>
                <th className="py-3 px-4">Current Role</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {users.map(u => (
                <tr key={u.id} className="hover:bg-slate-800/30">
                  <td className="py-3 px-4 text-white font-bold">{u.name}</td>
                  <td className="py-3 px-4 text-slate-300 font-mono">{u.email}</td>
                  <td className="py-3 px-4 text-slate-400">{new Date(u.createdAt).toLocaleDateString()}</td>
                  <td className="py-3 px-4">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase ${
                      u.role === 'admin' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      onClick={() => handleToggleUserRole(u)}
                      className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
                    >
                      {u.role === 'admin' ? 'Demote to User' : 'Promote to Admin'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB 5: SYSTEM ANALYTICS & AUDIT LOGS */}
      {activeTab === 'analytics' && analytics && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-navy-900 p-4 rounded-xl border border-slate-800">
              <div className="text-xs text-slate-400 font-semibold uppercase">Total TOTO Draws</div>
              <div className="text-2xl font-black text-gold-400 font-mono mt-1">
                {analytics.stats?.totalTotoDraws}
              </div>
            </div>
            <div className="bg-navy-900 p-4 rounded-xl border border-slate-800">
              <div className="text-xs text-slate-400 font-semibold uppercase">Total 4D Draws</div>
              <div className="text-2xl font-black text-cyan-400 font-mono mt-1">
                {analytics.stats?.totalFourDDraws}
              </div>
            </div>
            <div className="bg-navy-900 p-4 rounded-xl border border-slate-800">
              <div className="text-xs text-slate-400 font-semibold uppercase">System Uptime</div>
              <div className="text-2xl font-black text-purple-400 font-mono mt-1">
                {analytics.stats?.uptimeSeconds}s
              </div>
            </div>
            <div className="bg-navy-900 p-4 rounded-xl border border-slate-800">
              <div className="text-xs text-slate-400 font-semibold uppercase">Node Memory RSS</div>
              <div className="text-2xl font-black text-emerald-400 font-mono mt-1">
                {analytics.stats?.memoryRssMb} MB
              </div>
            </div>
          </div>

          {/* Audit Logs */}
          <div className="bg-navy-900 border border-slate-800 rounded-2xl p-5 shadow-xl">
            <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
              <Activity className="w-4 h-4 text-gold-400" />
              Administrative Audit Trail (Last 30 Events)
            </h4>
            <div className="space-y-2 max-h-72 overflow-y-auto">
              {analytics.auditLogs?.map((log, i) => (
                <div key={i} className="p-2.5 rounded-lg bg-navy-950 border border-slate-800/80 text-xs flex items-center justify-between">
                  <div>
                    <span className="font-bold text-gold-300 font-mono">{log.action}</span>
                    <span className="text-slate-300 ml-2">{log.detail}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 font-mono whitespace-nowrap ml-4">
                    {new Date(log.timestamp).toLocaleTimeString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

