import React from 'react';
import { 
  X, 
  Bookmark, 
  Trash2, 
  Copy, 
  Sparkles, 
  Calendar,
  Layers
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function FavouritesModal({ isOpen, onClose }) {
  const { favourites, removeFavourite, user } = useAuth();

  if (!isOpen) return null;

  const handleCopy = (numbers) => {
    const text = Array.isArray(numbers) ? numbers.join(', ') : String(numbers);
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-xl bg-navy-900 border border-gold-500/30 rounded-2xl shadow-2xl overflow-hidden max-h-[85vh] flex flex-col">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-gold-400 fill-gold-400/20" />
            <h3 className="text-lg font-bold text-white">
              My Saved Favourites ({favourites.length})
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4">
          {!user ? (
            <div className="p-6 text-center text-xs text-slate-400 space-y-2">
              <p>Please sign in to save and sync your favourite lottery combinations.</p>
            </div>
          ) : favourites.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-500 space-y-2">
              <Bookmark className="w-8 h-8 text-slate-600 mx-auto" />
              <p>You haven't saved any favourite combinations yet.</p>
              <p className="text-[11px] text-slate-600">Generate TOTO or 4D picks and click the bookmark button to save them here.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {favourites.map((fav) => (
                <div 
                  key={fav._id} 
                  className="p-4 rounded-xl bg-navy-950 border border-slate-800 flex items-center justify-between gap-4 hover:border-gold-500/40 transition-colors"
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        fav.type === 'toto' ? 'bg-gold-500/20 text-gold-300 border border-gold-500/30' : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      }`}>
                        {fav.type}
                      </span>
                      <strong className="text-xs text-white">{fav.label}</strong>
                    </div>

                    {/* Numbers display */}
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {Array.isArray(fav.numbers) ? (
                        fav.numbers.map((n, i) => (
                          <span key={i} className="w-7 h-7 rounded-full bg-slate-800 border border-gold-500/40 text-gold-200 font-bold text-xs flex items-center justify-center">
                            {n}
                          </span>
                        ))
                      ) : (
                        <span className="font-mono text-lg font-black tracking-widest text-gold-300 bg-slate-900 px-3 py-1 rounded-lg border border-slate-800">
                          {fav.numbers}
                        </span>
                      )}
                    </div>

                    {fav.notes && (
                      <p className="text-[10px] text-slate-400">{fav.notes}</p>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleCopy(fav.numbers)}
                      className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                      title="Copy numbers"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => removeFavourite(fav._id)}
                      className="p-2 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-300 hover:text-rose-400 transition-colors"
                      title="Delete from favourites"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

