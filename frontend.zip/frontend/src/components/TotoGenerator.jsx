import React, { useState } from 'react';
import { 
  Cpu, 
  Sparkles, 
  Flame, 
  Snowflake, 
  Dice5, 
  Star, 
  BookmarkPlus, 
  Check, 
  Copy, 
  RefreshCw, 
  Sliders,
  ShieldAlert,
  Info
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function TotoGenerator() {
  const { addFavourite } = useAuth();
  const [mode, setMode] = useState('ai_statistical');
  const [lineCount, setLineCount] = useState(3);
  const [favouritesInput, setFavouritesInput] = useState('');
  const [selectedBalls, setSelectedBalls] = useState([]);
  const [results, setResults] = useState([]);
  const [generating, setGenerating] = useState(false);
  const [savedIndex, setSavedIndex] = useState(null);
  const [copiedIndex, setCopiedIndex] = useState(null);

  const generatorModes = [
    {
      id: 'ai_statistical',
      label: 'AI Statistical Engine',
      icon: Cpu,
      badge: 'Recommended',
      desc: 'Optimizes hot scores, balances Odd/Even (3:3 or 4:2), Low/High, and ensures sum lands within 115 - 185.'
    },
    {
      id: 'random',
      label: 'Pure Random Pick',
      icon: Dice5,
      badge: '100% Unbiased',
      desc: 'Draws 6 unique numbers from 1 to 49 with true pseudo-random uniform probability.'
    },
    {
      id: 'hot',
      label: 'Hot Numbers Bias',
      icon: Flame,
      badge: 'Momentum',
      desc: 'Weights heavily towards top recurring numbers from the most recent 20-50 draws.'
    },
    {
      id: 'cold',
      label: 'Cold / Overdue Reversion',
      icon: Snowflake,
      badge: 'Cyclical',
      desc: 'Targets long-overdue numbers with extended drought gaps based on mean-reversion hypothesis.'
    },
    {
      id: 'favourites',
      label: 'User Lucky Base + AI',
      icon: Star,
      badge: 'Custom',
      desc: 'Incorporate your 1 to 5 favorite numbers; the AI completes the remaining slots mathematically.'
    }
  ];

  const handleToggleBall = (num) => {
    if (selectedBalls.includes(num)) {
      setSelectedBalls(selectedBalls.filter(n => n !== num));
    } else {
      if (selectedBalls.length < 5) {
        setSelectedBalls([...selectedBalls, num]);
      }
    }
  };

  const handleGenerate = async () => {
    setGenerating(true);
    setSavedIndex(null);
    setCopiedIndex(null);

    try {
      const favs = mode === 'favourites' ? selectedBalls : [];
      const res = await api.generateToto(mode, lineCount, favs);
      if (res.success) {
        setResults(res.combinations);
        confetti({
          particleCount: 70,
          spread: 70,
          origin: { y: 0.65 },
          colors: ['#f59e0b', '#fbbf24', '#ffffff', '#ef4444']
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setGenerating(false);
    }
  };

  const handleSave = async (combo, idx) => {
    const res = await addFavourite(
      'toto', 
      combo.numbers, 
      `TOTO ${combo.mode.toUpperCase()} (Line ${idx+1})`, 
      `Add'l: ${combo.additionalNumber} | Sum: ${combo.stats?.sum} | ${combo.stats?.oddEven}`
    );
    if (res.success) {
      setSavedIndex(idx);
      setTimeout(() => setSavedIndex(null), 3000);
    } else {
      alert(res.error || 'Please sign in to save favourite combinations.');
    }
  };

  const handleCopy = (combo, idx) => {
    const str = `${combo.numbers.join(', ')} + (${combo.additionalNumber})`;
    navigator.clipboard.writeText(str);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Header */}
      <div className="bg-navy-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <Cpu className="w-6 h-6 text-gold-400" />
            TOTO AI Combinatorial Generator
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Generate verified 6-number combinations (1 to 49) with 1 additional number according to rigorous mathematical constraints.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-navy-950 p-1.5 rounded-xl border border-slate-800">
          <span className="text-xs font-semibold text-slate-400 pl-2">Lines:</span>
          {[1, 3, 5, 10].map(cnt => (
            <button
              key={cnt}
              onClick={() => setLineCount(cnt)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                lineCount === cnt
                  ? 'bg-gold-500 text-navy-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cnt}
            </button>
          ))}
        </div>
      </div>

      {/* Mode Selection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {generatorModes.map(m => {
          const Icon = m.icon;
          const isSelected = mode === m.id;
          return (
            <div
              key={m.id}
              onClick={() => setMode(m.id)}
              className={`cursor-pointer rounded-2xl p-5 border transition-all duration-200 flex flex-col justify-between ${
                isSelected
                  ? 'bg-navy-850 border-gold-500 shadow-gold-glow scale-[1.02]'
                  : 'bg-navy-900/80 border-slate-800 hover:border-slate-700 hover:bg-navy-850/60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                    isSelected ? 'bg-gold-500 text-navy-950' : 'bg-slate-800 text-slate-300'
                  }`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border ${
                    isSelected
                      ? 'bg-gold-500/20 text-gold-300 border-gold-500/40'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}>
                    {m.badge}
                  </span>
                </div>
                <h3 className="font-bold text-white text-sm">{m.label}</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{m.desc}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                <span className={isSelected ? 'text-gold-400 font-semibold' : 'text-slate-500'}>
                  {isSelected ? '✓ Selected Mode' : 'Click to select'}
                </span>
                <span className="font-mono text-slate-500">6/49</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* If Favourites Mode: Ball Selector Matrix */}
      {mode === 'favourites' && (
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-6 shadow-xl animate-fadeIn">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Star className="w-4 h-4 text-gold-400 fill-gold-400" />
                Select 1 to 5 Favorite Numbers (Selected: {selectedBalls.length}/5)
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                The AI engine will lock these numbers and strategically generate the remaining picks to balance the combination.
              </p>
            </div>
            {selectedBalls.length > 0 && (
              <button
                onClick={() => setSelectedBalls([])}
                className="text-xs text-rose-400 hover:text-rose-300 font-semibold underline"
              >
                Clear picks
              </button>
            )}
          </div>

          <div className="grid grid-cols-7 sm:grid-cols-10 md:grid-cols-14 gap-2">
            {Array.from({ length: 49 }, (_, i) => i + 1).map((n) => {
              const picked = selectedBalls.includes(n);
              return (
                <button
                  key={n}
                  onClick={() => handleToggleBall(n)}
                  className={`h-9 rounded-xl font-bold text-xs transition-all flex items-center justify-center ${
                    picked
                      ? 'bg-gold-500 text-navy-950 font-black shadow-gold-glow scale-105'
                      : 'bg-navy-950 text-slate-300 border border-slate-800 hover:border-slate-700 hover:text-white'
                  }`}
                >
                  {n}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Generate Action Button */}
      <div className="flex justify-center pt-2">
        <button
          onClick={handleGenerate}
          disabled={generating}
          className="flex items-center justify-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-gold-500 via-gold-400 to-amber-600 hover:from-gold-400 hover:to-amber-500 text-navy-950 font-black text-sm uppercase tracking-wider shadow-gold-glow-lg transform hover:-translate-y-0.5 transition-all"
        >
          {generating ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
          <span>{generating ? 'Simulating Combinations...' : `Generate ${lineCount} TOTO Combinations`}</span>
        </button>
      </div>

      {/* Results Display */}
      {results.length > 0 && (
        <div className="space-y-4 pt-4 animate-fadeIn">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Check className="w-5 h-5 text-emerald-400" />
              Generated Suggested Combinations ({results.length} Lines)
            </h3>
            <span className="text-xs text-slate-400">Strictly 6 unique numbers (1-49) + 1 additional</span>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {results.map((combo, idx) => (
              <div 
                key={idx}
                className="bg-gradient-to-r from-navy-900 via-navy-850 to-navy-900 border border-gold-500/30 rounded-2xl p-5 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-5"
              >
                {/* Combination Number Balls */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                  <span className="text-xs font-mono font-bold text-gold-400 bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-800 self-start sm:self-auto">
                    Line {idx + 1}
                  </span>

                  <div className="flex flex-wrap items-center gap-2.5">
                    {combo.numbers.map((num) => (
                      <div key={num} className="ball-toto w-10 h-10 text-sm">
                        {num}
                      </div>
                    ))}

                    <span className="text-gold-400 font-extrabold text-base px-1">+</span>

                    <div className="ball-toto ball-additional w-10 h-10 text-sm" title="Additional Number">
                      {combo.additionalNumber}
                    </div>
                  </div>
                </div>

                {/* Right: Stats & Actions */}
                <div className="flex items-center justify-between sm:justify-end gap-3 border-t sm:border-t-0 border-slate-800 pt-3 sm:pt-0">
                  {combo.stats && (
                    <div className="flex items-center gap-2 text-xs">
                      <span className="px-2 py-1 rounded-lg bg-navy-950 border border-slate-800 text-slate-300 font-mono">
                        Sum: <strong>{combo.stats.sum}</strong>
                      </span>
                      <span className="px-2 py-1 rounded-lg bg-navy-950 border border-slate-800 text-purple-300 font-mono">
                        {combo.stats.oddEven}
                      </span>
                      <span className="px-2 py-1 rounded-lg bg-gold-500/10 border border-gold-500/30 text-gold-300 font-bold">
                        AI Score: {combo.stats.aiConfidenceScore}%
                      </span>
                    </div>
                  )}

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleCopy(combo, idx)}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                      title="Copy to clipboard"
                    >
                      {copiedIndex === idx ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                    </button>
                    <button
                      onClick={() => handleSave(combo, idx)}
                      className="p-2 rounded-xl bg-navy-800 hover:bg-gold-500 hover:text-navy-950 text-gold-400 border border-gold-500/30 transition-all"
                      title="Save combination to Favourites"
                    >
                      {savedIndex === idx ? <Check className="w-4 h-4 text-emerald-400" /> : <BookmarkPlus className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}

