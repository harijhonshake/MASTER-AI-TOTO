import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Sparkles, 
  Calendar, 
  TrendingUp, 
  Layers, 
  Search, 
  CheckCircle2, 
  BookmarkPlus, 
  RefreshCw, 
  ChevronRight,
  Zap,
  Grid
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function FourDDashboard({ onNavigateToAnalysis, onNavigateToGenerator }) {
  const { addFavourite } = useAuth();
  const [latestDraw, setLatestDraw] = useState(null);
  const [previousDraw, setPreviousDraw] = useState(null);
  const [stats, setStats] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ total: 0, pages: 1 });

  // Quick 4D Pick
  const [quickPick, setQuickPick] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    loadHistory(page, search);
  }, [page, search]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [latestRes, statsRes] = await Promise.all([
        api.getFourDLatest(),
        api.getFourDStats()
      ]);
      if (latestRes.success) {
        setLatestDraw(latestRes.latest);
        setPreviousDraw(latestRes.previous);
      }
      if (statsRes.success) {
        setStats(statsRes);
      }
    } catch (e) {
      console.error('Error loading 4D dashboard:', e);
    } finally {
      setLoading(false);
    }
  };

  const loadHistory = async (p = 1, q = '') => {
    try {
      const res = await api.getFourDHistory(p, 10, q);
      if (res.success) {
        setHistory(res.data);
        setPagination(res.pagination);
      }
    } catch (e) {
      console.error('Error loading 4D history:', e);
    }
  };

  const handleQuickGenerate = async () => {
    setGenerating(true);
    setSaveSuccess(false);
    try {
      const res = await api.generateFourD('ai_statistical', 1);
      if (res.success && res.combinations.length > 0) {
        setQuickPick(res.combinations[0]);
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.8 },
          colors: ['#f59e0b', '#fbbf24', '#ffffff']
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setGenerating(false);
    }
  };

  const handleSaveQuickPick = async () => {
    if (!quickPick) return;
    const res = await addFavourite('4d', [quickPick.number], '4D Quick Pick', `Pattern: ${quickPick.pattern} | Front: ${quickPick.frontPair} | Back: ${quickPick.backPair}`);
    if (res.success) {
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } else {
      alert(res.error || 'Please log in to save favourite combinations.');
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* 1. LATEST 4D DRAW HERO CARD */}
      {latestDraw && (
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-navy-900 via-navy-850 to-navy-900 border border-gold-500/30 p-6 sm:p-8 shadow-2xl">
          <div className="absolute top-0 right-0 w-96 h-96 bg-gold-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

          <div className="relative z-10 space-y-6">
            
            {/* Top Bar: Draw Info */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex flex-wrap items-center gap-2.5 mb-1.5">
                  <span className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-gold-500/20 text-gold-300 border border-gold-500/40 flex items-center gap-1.5 shadow-sm">
                    <Trophy className="w-3.5 h-3.5 text-gold-400" />
                    Latest 4D Draw
                  </span>
                  <span className="text-xs text-slate-400 flex items-center gap-1 bg-slate-800/60 px-2.5 py-1 rounded-full">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    {latestDraw.drawDate} ({latestDraw.drawDay})
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-300 bg-slate-800/80 px-2.5 py-1 rounded-full border border-slate-700">
                    Draw #{latestDraw.drawNumber}
                  </span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                  Singapore Pools <span className="gold-gradient-text">4-DIGIT (4D)</span>
                </h2>
              </div>

              <div className="text-xs text-slate-400 bg-navy-950/60 px-3 py-2 rounded-xl border border-slate-800">
                <span>Draw Venue: </span>
                <strong className="text-slate-200">{latestDraw.venue}</strong>
              </div>
            </div>

            {/* TOP 3 PRIZES PODIUM */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              
              {/* 1st Prize */}
              <div className="relative rounded-2xl bg-gradient-to-b from-amber-500/20 via-navy-950 to-navy-950 border-2 border-gold-400 p-5 shadow-gold-glow flex flex-col items-center justify-center text-center transform md:-translate-y-1">
                <div className="absolute -top-3 px-3 py-0.5 rounded-full bg-gold-500 text-navy-950 font-black text-xs uppercase tracking-wider shadow">
                  🥇 1st Prize
                </div>
                <span className="mt-2 text-4xl sm:text-5xl font-mono font-black tracking-widest text-gold-300 drop-shadow-md">
                  {latestDraw.firstPrize}
                </span>
                <span className="text-[11px] text-slate-400 mt-2 font-medium">
                  Prize: $2,000 / $3,000 per $1 big/small bet
                </span>
              </div>

              {/* 2nd Prize */}
              <div className="rounded-2xl bg-navy-950/80 border border-slate-700/80 p-5 flex flex-col items-center justify-center text-center shadow-lg">
                <div className="px-3 py-0.5 rounded-full bg-slate-700 text-slate-200 font-bold text-xs uppercase tracking-wider mb-2">
                  🥈 2nd Prize
                </div>
                <span className="text-3xl sm:text-4xl font-mono font-bold tracking-widest text-slate-100">
                  {latestDraw.secondPrize}
                </span>
                <span className="text-[11px] text-slate-400 mt-2 font-medium">
                  Prize: $1,000 / $2,000 per $1
                </span>
              </div>

              {/* 3rd Prize */}
              <div className="rounded-2xl bg-navy-950/80 border border-slate-700/80 p-5 flex flex-col items-center justify-center text-center shadow-lg">
                <div className="px-3 py-0.5 rounded-full bg-amber-800/60 text-amber-300 font-bold text-xs uppercase tracking-wider mb-2">
                  🥉 3rd Prize
                </div>
                <span className="text-3xl sm:text-4xl font-mono font-bold tracking-widest text-slate-100">
                  {latestDraw.thirdPrize}
                </span>
                <span className="text-[11px] text-slate-400 mt-2 font-medium">
                  Prize: $490 / $800 per $1
                </span>
              </div>

            </div>

            {/* STARTER & CONSOLATION NUMBERS */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pt-2">
              
              {/* 10 Starter Prizes */}
              <div className="bg-navy-950/70 border border-slate-800/80 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <Grid className="w-3.5 h-3.5 text-gold-400" />
                    Starter Prizes (10 Numbers)
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">$250 each</span>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {latestDraw.starterPrizes?.map((num, i) => (
                    <div key={i} className="tile-4d py-2 px-1 text-center rounded-lg font-bold text-xs text-slate-200">
                      {num}
                    </div>
                  ))}
                </div>
              </div>

              {/* 10 Consolation Prizes */}
              <div className="bg-navy-950/70 border border-slate-800/80 rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                    <Grid className="w-3.5 h-3.5 text-cyan-400" />
                    Consolation Prizes (10 Numbers)
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono">$60 each</span>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {latestDraw.consolationPrizes?.map((num, i) => (
                    <div key={i} className="tile-4d py-2 px-1 text-center rounded-lg font-bold text-xs text-slate-300">
                      {num}
                    </div>
                  ))}
                </div>
              </div>

            </div>

          </div>
        </div>
      )}

      {/* 2. STATISTICAL SUMMARY HIGHLIGHTS */}
      {stats && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Card 1: Top 1st Prize Ending Digit */}
          <div className="bg-navy-900/80 border border-slate-800 rounded-xl p-5 hover:border-gold-500/40 transition-colors">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Top 1st Prize Ending Digit</span>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-3xl font-black text-gold-400 font-mono">
                {stats.lastDigitAnalysis?.mostFrequent}
              </span>
              <span className="text-xs text-slate-400">Most frequent unit</span>
            </div>
            <p className="mt-2 text-[11px] text-slate-400">
              Evaluated across all verified historical 1st prizes.
            </p>
          </div>

          {/* Card 2: Top Front Pair */}
          <div className="bg-navy-900/80 border border-slate-800 rounded-xl p-5 hover:border-gold-500/40 transition-colors">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Top Hot Front Pair</span>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-3xl font-black text-cyan-400 font-mono">
                {stats.pairsAnalysis?.topFrontPairs[0]?.pair || '88'}
              </span>
              <span className="text-xs text-slate-400">{stats.pairsAnalysis?.topFrontPairs[0]?.count || 0} hits</span>
            </div>
            <p className="mt-2 text-[11px] text-slate-400">
              Leading two digits (Thousands + Hundreds).
            </p>
          </div>

          {/* Card 3: Dominant Digit Pattern */}
          <div className="bg-navy-900/80 border border-slate-800 rounded-xl p-5 hover:border-gold-500/40 transition-colors">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Most Drawn Pattern</span>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-2xl font-black text-purple-300">ABCD (Single)</span>
              <span className="text-xs text-purple-400 font-bold">~50.4%</span>
            </div>
            <p className="mt-2 text-[11px] text-slate-400">
              Followed by Double (AABC) at ~43.2%.
            </p>
          </div>

          {/* Card 4: Historical Digit Sum */}
          <div className="bg-navy-900/80 border border-slate-800 rounded-xl p-5 hover:border-gold-500/40 transition-colors">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Average 4-Digit Sum</span>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-3xl font-black text-gold-300 font-mono">
                {stats.averageDigitSum || 18.0}
              </span>
              <span className="text-xs text-slate-400">Expected: 18.0</span>
            </div>
            <p className="mt-2 text-[11px] text-slate-400">
              Mean sum of 4 digits (0+0+0+0 to 9+9+9+9).
            </p>
          </div>

        </div>
      )}

      {/* 3. QUICK AI 4D GENERATOR BANNER */}
      <div className="bg-gradient-to-r from-navy-900 via-navy-850 to-navy-900 border border-gold-500/30 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-gold-400 text-xs font-bold uppercase tracking-wider">
            <Zap className="w-4 h-4" />
            Instant 4D AI Generation
          </div>
          <h3 className="text-xl font-bold text-white mt-1">
            Generate an AI-Weighted 4D Number (0000-9999)
          </h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Strictly 4 digits including leading zeros, balancing position-by-position frequency and top historical pairs.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
          {quickPick && (
            <div className="flex items-center gap-3 bg-navy-950 px-4 py-2 rounded-xl border border-gold-500/40 animate-fadeIn">
              <span className="font-mono text-2xl font-black text-gold-300 tracking-widest">
                {quickPick.number}
              </span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                {quickPick.pattern}
              </span>
              <button
                onClick={handleSaveQuickPick}
                className="p-1.5 rounded-lg bg-navy-800 hover:bg-navy-700 text-gold-400 hover:text-gold-300 transition-colors"
                title="Save this combination"
              >
                {saveSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <BookmarkPlus className="w-4 h-4" />}
              </button>
            </div>
          )}

          <button
            onClick={handleQuickGenerate}
            disabled={generating}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-gold-500 via-gold-400 to-amber-600 hover:from-gold-400 hover:to-amber-500 text-navy-950 font-black text-xs uppercase tracking-wider shadow-gold-glow transition-all"
          >
            {generating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>{generating ? 'Generating...' : 'Quick 4D Pick'}</span>
          </button>

          <button
            onClick={onNavigateToGenerator}
            className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-4 py-3 rounded-xl bg-navy-800 hover:bg-navy-700 border border-slate-700 text-slate-200 text-xs font-bold transition-all"
          >
            <span>7 4D Generators</span>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        </div>
      </div>

      {/* 4. PREVIOUS 4D DRAWS EXPLORER */}
      <div className="bg-navy-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <span>Historical Singapore 4D Results</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                {pagination.total} Draws Verified
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              1st, 2nd, 3rd, Starter, and Consolation prize records.
            </p>
          </div>

          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search draw #, date, or 4D number..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-navy-950 border border-slate-700/80 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-gold-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-navy-950/70 text-slate-400 uppercase tracking-wider text-[11px] font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Draw #</th>
                <th className="py-3 px-4">Draw Date</th>
                <th className="py-3 px-4 text-center">1st Prize</th>
                <th className="py-3 px-4 text-center">2nd Prize</th>
                <th className="py-3 px-4 text-center">3rd Prize</th>
                <th className="py-3 px-4">Starters Sample</th>
                <th className="py-3 px-4">Consolations Sample</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {history.map((draw) => (
                <tr key={draw.drawNumber} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-gold-400">
                    #{draw.drawNumber}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    <div>{draw.drawDate}</div>
                    <div className="text-[10px] text-slate-500">{draw.drawDay}</div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="font-mono font-black text-sm text-gold-400 bg-gold-500/10 border border-gold-500/30 px-2.5 py-1 rounded-lg">
                      {draw.firstPrize}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="font-mono font-bold text-sm text-slate-200 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
                      {draw.secondPrize}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="font-mono font-bold text-sm text-amber-200/90 bg-slate-800 px-2.5 py-1 rounded-lg border border-slate-700">
                      {draw.thirdPrize}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                    {draw.starterPrizes?.slice(0, 4).join(', ')}...
                  </td>
                  <td className="py-3 px-4 text-slate-400 font-mono text-[11px]">
                    {draw.consolationPrizes?.slice(0, 4).join(', ')}...
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>
            Page {pagination.page} of {pagination.pages || 1}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed font-medium text-slate-200"
            >
              Previous
            </button>
            <button
              onClick={() => setPage(p => Math.min(pagination.pages || 1, p + 1))}
              disabled={page >= pagination.pages}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed font-medium text-slate-200"
            >
              Next
            </button>
          </div>
        </div>
      </div>

    </div>
  );
}

