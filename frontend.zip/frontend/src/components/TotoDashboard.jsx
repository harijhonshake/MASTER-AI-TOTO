import React, { useState, useEffect } from 'react';
import { 
  Trophy, 
  Flame, 
  Snowflake, 
  Sparkles, 
  Calendar, 
  DollarSign, 
  TrendingUp, 
  CheckCircle2, 
  ChevronRight,
  RefreshCw,
  BookmarkPlus,
  Search,
  Zap
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function TotoDashboard({ onNavigateToAnalysis, onNavigateToGenerator }) {
  const { addFavourite } = useAuth();
  const [latestDraw, setLatestDraw] = useState(null);
  const [previousDraw, setPreviousDraw] = useState(null);
  const [stats, setStats] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ total: 0, pages: 1 });
  
  // Quick Generator State
  const [quickPick, setQuickPick] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    loadHistory(page, search);
  }, [page, search]);

  const loadData = async () => {
    setLoading(true);
    try {
      const [latestRes, statsRes] = await Promise.all([
        api.getTotoLatest(),
        api.getTotoStats()
      ]);
      if (latestRes.success) {
        setLatestDraw(latestRes.latest);
        setPreviousDraw(latestRes.previous);
      }
      if (statsRes.success) {
        setStats(statsRes);
      }
    } catch (e) {
      console.error('Error loading TOTO dashboard:', e);
    } finally {
      setLoading(false);
    }
  };

  const loadHistory = async (p = 1, q = '') => {
    try {
      const res = await api.getTotoHistory(p, 10, q);
      if (res.success) {
        setHistory(res.data);
        setPagination(res.pagination);
      }
    } catch (e) {
      console.error('Error loading history:', e);
    }
  };

  const handleQuickGenerate = async () => {
    setGenerating(true);
    setSaveSuccess(false);
    try {
      const res = await api.generateToto('ai_statistical', 1);
      if (res.success && res.combinations.length > 0) {
        setQuickPick(res.combinations[0]);
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.8 },
          colors: ['#f59e0b', '#fbbf24', '#ffffff']
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setGenerating(false);
    }
  };

  const handleSaveQuickPick = async () => {
    if (!quickPick) return;
    const res = await addFavourite('toto', quickPick.numbers, 'Dashboard Quick Pick', `Add: ${quickPick.additionalNumber}`);
    if (res.success) {
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } else {
      alert(res.error || 'Please log in to save favourite combinations.');
    }
  };

  const formatSGD = (amount) => {
    return new Intl.NumberFormat('en-SG', { style: 'currency', currency: 'SGD', maximumFractionDigits: 0 }).format(amount || 0);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* 1. LATEST DRAW HERO CARD */}
      {latestDraw && (
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-navy-900 via-navy-850 to-navy-900 border border-gold-500/30 p-6 sm:p-8 shadow-2xl">
          {/* Background Ambient Glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-gold-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
          
          <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
            
            {/* Left: Draw Info & Title */}
            <div>
              <div className="flex flex-wrap items-center gap-2.5 mb-2">
                <span className="px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-gold-500/20 text-gold-300 border border-gold-500/40 flex items-center gap-1.5 shadow-sm">
                  <Trophy className="w-3.5 h-3.5 text-gold-400" />
                  Latest Official Draw
                </span>
                <span className="text-xs text-slate-400 flex items-center gap-1 bg-slate-800/60 px-2.5 py-1 rounded-full">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  {latestDraw.drawDate} ({latestDraw.drawDay})
                </span>
                <span className="text-xs font-mono font-bold text-slate-300 bg-slate-800/80 px-2.5 py-1 rounded-full border border-slate-700">
                  Draw #{latestDraw.drawNumber}
                </span>
                {latestDraw.isCascade && (
                  <span className="text-xs font-black uppercase tracking-wider bg-red-600/30 text-red-300 border border-red-500/40 px-2.5 py-0.5 rounded-full animate-pulse">
                    ⚡ Cascade Draw
                  </span>
                )}
              </div>

              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                Singapore Pools <span className="gold-gradient-text">TOTO 6/49</span>
              </h2>

              <div className="mt-2 flex items-center gap-2 text-slate-300 text-sm">
                <span>Jackpot Prize Pool:</span>
                <span className="text-xl sm:text-2xl font-black text-gold-400 tracking-wide font-mono drop-shadow">
                  {formatSGD(latestDraw.jackpot)}
                </span>
              </div>
            </div>

            {/* Right: Winning Numbers 3D Balls */}
            <div className="flex flex-col items-start lg:items-end gap-3">
              <span className="text-xs uppercase font-bold tracking-wider text-slate-400">
                Winning Numbers & Additional
              </span>

              <div className="flex flex-wrap items-center gap-2.5 sm:gap-3.5">
                {latestDraw.winningNumbers.map((num, i) => (
                  <div 
                    key={i} 
                    className="ball-toto w-11 h-11 sm:w-13 sm:h-13 text-base sm:text-lg cursor-default"
                    title={`Winning Number #${i+1}: ${num}`}
                  >
                    {num}
                  </div>
                ))}

                <span className="text-gold-400 font-extrabold text-xl px-1">+</span>

                {/* Additional Number Ball */}
                <div 
                  className="ball-toto ball-additional w-11 h-11 sm:w-13 sm:h-13 text-base sm:text-lg cursor-default"
                  title={`Additional Number: ${latestDraw.additionalNumber}`}
                >
                  {latestDraw.additionalNumber}
                </div>
              </div>

              {/* Group 1 / Group 2 Winners */}
              <div className="flex items-center gap-4 text-xs text-slate-400 pt-1">
                <span>Group 1 Winners: <strong className="text-white">{latestDraw.group1Winners}</strong></span>
                <span>•</span>
                <span>Group 2 Winners: <strong className="text-white">{latestDraw.group2Winners}</strong></span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. STATISTICAL SUMMARY HIGHLIGHTS */}
      {stats && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          
          {/* Card 1: Top Hot Numbers */}
          <div className="bg-navy-900/80 border border-slate-800 rounded-xl p-5 hover:border-gold-500/40 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Top Hot Numbers</span>
              <div className="w-8 h-8 rounded-lg bg-red-500/10 text-red-400 flex items-center justify-center border border-red-500/20">
                <Flame className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              {stats.hotNumbers.slice(0, 4).map((num) => (
                <span key={num} className="w-9 h-9 rounded-full bg-red-950/80 border border-red-500/50 text-red-200 font-extrabold text-sm flex items-center justify-center shadow-sm">
                  {num}
                </span>
              ))}
            </div>
            <p className="mt-2 text-[11px] text-slate-400">
              Highest frequency in recent draw cycles.
            </p>
          </div>

          {/* Card 2: Top Cold / Overdue Numbers */}
          <div className="bg-navy-900/80 border border-slate-800 rounded-xl p-5 hover:border-gold-500/40 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Overdue (Cold)</span>
              <div className="w-8 h-8 rounded-lg bg-cyan-500/10 text-cyan-400 flex items-center justify-center border border-cyan-500/20">
                <Snowflake className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-center gap-2">
              {stats.coldNumbers.slice(0, 4).map((num) => (
                <span key={num} className="w-9 h-9 rounded-full bg-cyan-950/80 border border-cyan-500/50 text-cyan-200 font-extrabold text-sm flex items-center justify-center shadow-sm">
                  {num}
                </span>
              ))}
            </div>
            <p className="mt-2 text-[11px] text-slate-400">
              Longest drought interval since last drawn.
            </p>
          </div>

          {/* Card 3: Odd / Even Dominance */}
          <div className="bg-navy-900/80 border border-slate-800 rounded-xl p-5 hover:border-gold-500/40 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Top Odd-Even Pattern</span>
              <div className="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center border border-purple-500/20">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-2xl font-black text-purple-300">3 Odd - 3 Even</span>
              <span className="text-xs text-purple-400 font-bold">~33.3%</span>
            </div>
            <p className="mt-2 text-[11px] text-slate-400">
              Optimal mathematical distribution in 6/49 lotteries.
            </p>
          </div>

          {/* Card 4: Historical Average Sum */}
          <div className="bg-navy-900/80 border border-slate-800 rounded-xl p-5 hover:border-gold-500/40 transition-colors">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Mean Sum Sweet Spot</span>
              <div className="w-8 h-8 rounded-lg bg-gold-500/10 text-gold-400 flex items-center justify-center border border-gold-500/20">
                <Sparkles className="w-4 h-4" />
              </div>
            </div>
            <div className="mt-3 flex items-baseline gap-2">
              <span className="text-2xl font-black text-gold-300 font-mono">
                {stats.sumAnalysis?.averageSum || 150}
              </span>
              <span className="text-xs text-slate-400">Range: 115 - 185</span>
            </div>
            <p className="mt-2 text-[11px] text-slate-400">
              Theoretical bell curve mean is 150.0.
            </p>
          </div>

        </div>
      )}

      {/* 3. QUICK AI GENERATOR BANNER */}
      <div className="bg-gradient-to-r from-navy-900 via-navy-850 to-navy-900 border border-gold-500/30 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-gold-400 text-xs font-bold uppercase tracking-wider">
            <Zap className="w-4 h-4" />
            Instant Statistical Simulation
          </div>
          <h3 className="text-xl font-bold text-white mt-1">
            Need an AI-Balanced TOTO Combination?
          </h3>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Generates 6 unique numbers (1-49) + 1 additional number balancing Hot momentum, Odd/Even ratio, and sum variance.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
          {quickPick && (
            <div className="flex items-center gap-2 bg-navy-950 px-4 py-2 rounded-xl border border-gold-500/40 animate-fadeIn">
              <div className="flex items-center gap-1.5">
                {quickPick.numbers.map((n) => (
                  <span key={n} className="w-8 h-8 rounded-full bg-gold-500 text-navy-950 font-black text-xs flex items-center justify-center shadow-sm">
                    {n}
                  </span>
                ))}
                <span className="text-gold-400 font-bold px-0.5">+</span>
                <span className="w-8 h-8 rounded-full bg-rose-600 text-white font-black text-xs flex items-center justify-center shadow-sm">
                  {quickPick.additionalNumber}
                </span>
              </div>
              <button
                onClick={handleSaveQuickPick}
                className="ml-2 p-1.5 rounded-lg bg-navy-800 hover:bg-navy-700 text-gold-400 hover:text-gold-300 transition-colors"
                title="Save this combination"
              >
                {saveSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <BookmarkPlus className="w-4 h-4" />}
              </button>
            </div>
          )}

          <button
            onClick={handleQuickGenerate}
            disabled={generating}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-gold-500 via-gold-400 to-amber-600 hover:from-gold-400 hover:to-amber-500 text-navy-950 font-black text-xs uppercase tracking-wider shadow-gold-glow transition-all"
          >
            {generating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>{generating ? 'Generating...' : 'Quick AI Pick'}</span>
          </button>

          <button
            onClick={onNavigateToGenerator}
            className="w-full sm:w-auto flex items-center justify-center gap-1.5 px-4 py-3 rounded-xl bg-navy-800 hover:bg-navy-700 border border-slate-700 text-slate-200 text-xs font-bold transition-all"
          >
            <span>Advanced Generator</span>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        </div>
      </div>

      {/* 4. PREVIOUS HISTORICAL RESULTS TABLE */}
      <div className="bg-navy-900/90 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <span>Historical TOTO Draws</span>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                {pagination.total} Draws Verified
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Verified Singapore Pools winning numbers, dates, and prize tiers.
            </p>
          </div>

          {/* Search Box */}
          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search draw # or date..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-navy-950 border border-slate-700/80 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-gold-500"
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-navy-950/70 text-slate-400 uppercase tracking-wider text-[11px] font-semibold border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Draw #</th>
                <th className="py-3 px-4">Draw Date</th>
                <th className="py-3 px-4">Winning Numbers (6/49)</th>
                <th className="py-3 px-4 text-center">Additional</th>
                <th className="py-3 px-4">Jackpot</th>
                <th className="py-3 px-4 text-center">Cascade</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {history.map((draw) => (
                <tr key={draw.drawNumber} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-4 font-mono font-bold text-gold-400">
                    #{draw.drawNumber}
                  </td>
                  <td className="py-3 px-4 text-slate-300">
                    <div>{draw.drawDate}</div>
                    <div className="text-[10px] text-slate-500">{draw.drawDay}</div>
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      {draw.winningNumbers.map((n) => (
                        <span key={n} className="w-7 h-7 rounded-full bg-slate-800 border border-gold-500/40 text-gold-200 font-extrabold text-xs flex items-center justify-center">
                          {n}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-center">
                    <span className="inline-flex w-7 h-7 rounded-full bg-rose-600/80 border border-rose-400 text-white font-extrabold text-xs items-center justify-center">
                      {draw.additionalNumber}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-200">
                    {formatSGD(draw.jackpot)}
                  </td>
                  <td className="py-3 px-4 text-center">
                    {draw.isCascade ? (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        Cascade
                      </span>
                    ) : (
                      <span className="text-slate-600">-</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>
            Page {pagination.page} of {pagination.pages || 1}
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed font-medium text-slate-200"
            >
              Previous
            </button>
            <button
              onClick={() => setPage(p => Math.min(pagination.pages || 1, p + 1))}
              disabled={page >= pagination.pages}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed font-medium text-slate-200"
            >
              Next
            </button>
          </div>
        </div>
      </div>

    </div>
  );
}

