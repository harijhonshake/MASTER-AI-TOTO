import React from 'react';
import { AlertTriangle, ShieldCheck } from 'lucide-react';

export default function DisclaimerBanner() {
  return (
    <div className="bg-gradient-to-r from-amber-950/70 via-navy-900 to-amber-950/70 border-y border-gold-500/30 px-4 py-2.5 text-xs text-amber-200/90 shadow-md">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <AlertTriangle className="w-4 h-4 text-gold-400 flex-shrink-0 animate-pulse" />
          <span>
            <strong className="text-gold-300 font-semibold tracking-wide">RESPONSIBLE PLAY MANDATE:</strong> Historical lottery patterns and statistical frequency cannot predict future outcomes. Every lottery draw is an independent random event. All generated combinations are mathematical suggestions, not guaranteed winning numbers.
          </span>
        </div>
        <div className="hidden sm:flex items-center gap-1.5 text-gold-400 font-semibold text-[11px] bg-gold-500/10 px-2 py-0.5 rounded border border-gold-500/20 whitespace-nowrap">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>18+ Strictly</span>
        </div>
      </div>
    </div>
  );
}

