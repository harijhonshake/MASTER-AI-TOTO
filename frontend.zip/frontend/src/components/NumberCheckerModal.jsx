import React, { useState } from 'react';
import { 
  X, 
  Search, 
  Trophy, 
  CheckCircle2, 
  AlertCircle, 
  Calendar, 
  History, 
  Sparkles 
} from 'lucide-react';
import { api } from '../services/api';

export default function NumberCheckerModal({ isOpen, onClose }) {
  const [activeTab, setActiveTab] = useState('toto'); // toto or 4d
  
  // TOTO state
  const [selectedToto, setSelectedToto] = useState([]);
  const [totoResults, setTotoResults] = useState(null);
  const [loadingToto, setLoadingToto] = useState(false);

  // 4D state
  const [fourDInput, setFourDInput] = useState('');
  const [fourDResults, setFourDResults] = useState(null);
  const [loading4D, setLoading4D] = useState(false);

  if (!isOpen) return null;

  const handleToggleTotoBall = (n) => {
    if (selectedToto.includes(n)) {
      setSelectedToto(selectedToto.filter(x => x !== n));
    } else {
      if (selectedToto.length < 6) {
        setSelectedToto([...selectedToto, n].sort((a, b) => a - b));
      }
    }
  };

  const handleCheckToto = async () => {
    if (selectedToto.length !== 6) return;
    setLoadingToto(true);
    setTotoResults(null);
    try {
      const res = await api.checkTotoNumbers(selectedToto);
      if (res.success) {
        setTotoResults(res);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingToto(false);
    }
  };

  const handleCheck4D = async (e) => {
    if (e) e.preventDefault();
    if (!/^\d{4}$/.test(fourDInput.trim())) return;
    setLoading4D(true);
    setFourDResults(null);
    try {
      const res = await api.checkFourDNumber(fourDInput.trim());
      if (res.success) {
        setFourDResults(res);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading4D(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-navy-950/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl bg-navy-900 border border-gold-500/30 rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        
        {/* Top Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Search className="w-5 h-5 text-gold-400" />
            <h3 className="text-lg font-bold text-white">
              Historical Winning Number Checker
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 bg-navy-950/60 p-2 gap-2">
          <button
            onClick={() => setActiveTab('toto')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'toto'
                ? 'bg-gold-500 text-navy-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Singapore TOTO Checker (Pick 6)
          </button>
          <button
            onClick={() => setActiveTab('4d')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === '4d'
                ? 'bg-gold-500 text-navy-950 shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Singapore 4D Checker (4 Digits)
          </button>
        </div>

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-6">
          
          {/* TOTO CHECKER PANEL */}
          {activeTab === 'toto' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-white">Select Your 6 Numbers:</span>
                  <div className="flex items-center gap-2 mt-1">
                    {selectedToto.length === 0 ? (
                      <span className="text-xs text-slate-500 italic">No numbers selected yet (click below)</span>
                    ) : (
                      selectedToto.map(n => (
                        <span key={n} className="w-8 h-8 rounded-full bg-gold-500 text-navy-950 font-black text-xs flex items-center justify-center">
                          {n}
                        </span>
                      ))
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {selectedToto.length > 0 && (
                    <button
                      onClick={() => setSelectedToto([])}
                      className="text-xs text-slate-400 hover:text-white underline"
                    >
                      Reset
                    </button>
                  )}
                  <button
                    onClick={handleCheckToto}
                    disabled={selectedToto.length !== 6 || loadingToto}
                    className="px-4 py-2 rounded-xl bg-gold-500 hover:bg-gold-400 disabled:opacity-40 text-navy-950 font-bold text-xs shadow-gold-glow transition-all"
                  >
                    {loadingToto ? 'Checking...' : `Check 6 Numbers (${selectedToto.length}/6)`}
                  </button>
                </div>
              </div>

              {/* Number Grid 1 to 49 */}
              <div className="grid grid-cols-7 sm:grid-cols-10 gap-1.5 p-3 rounded-xl bg-navy-950 border border-slate-800">
                {Array.from({ length: 49 }, (_, i) => i + 1).map((num) => {
                  const isSelected = selectedToto.includes(num);
                  return (
                    <button
                      key={num}
                      onClick={() => handleToggleTotoBall(num)}
                      className={`h-8 rounded-lg font-bold text-xs transition-all ${
                        isSelected
                          ? 'bg-gold-500 text-navy-950 font-black shadow-sm'
                          : 'bg-navy-900 text-slate-300 border border-slate-800 hover:border-slate-700 hover:text-white'
                      }`}
                    >
                      {num}
                    </button>
                  );
                })}
              </div>

              {/* Results */}
              {totoResults && (
                <div className="mt-4 pt-4 border-t border-slate-800 space-y-3 animate-fadeIn">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <Trophy className="w-4 h-4 text-gold-400" />
                      Historical Matches ({totoResults.matchesCount} Draws with 3+ Matches)
                    </h4>
                    <span className="text-xs text-slate-400">Scanned {totoResults.totalCheckedDraws} draws</span>
                  </div>

                  {totoResults.matchesCount === 0 ? (
                    <div className="p-4 rounded-xl bg-navy-950 border border-slate-800 text-center text-xs text-slate-400">
                      No past draws contained 3 or more of these numbers.
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-56 overflow-y-auto">
                      {totoResults.matches.map((m, i) => (
                        <div key={i} className="p-3 rounded-xl bg-navy-950 border border-slate-800 flex items-center justify-between text-xs">
                          <div>
                            <span className="font-bold text-gold-400">Draw #{m.drawNumber}</span>
                            <span className="text-slate-400 ml-2">({m.drawDate})</span>
                            <div className="text-[11px] text-slate-300 mt-0.5">
                              Matched {m.matchedCount} numbers: <strong className="text-gold-300">{m.matchedNumbers.join(', ')}</strong>
                              {m.hasAdditional && <span className="text-rose-400 ml-1">+ Additional ({m.additionalNumber})</span>}
                            </div>
                          </div>
                          {m.prizeGroup && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-gold-500/20 text-gold-300 border border-gold-500/40">
                              {m.prizeGroup}
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* 4D CHECKER PANEL */}
          {activeTab === '4d' && (
            <div className="space-y-4">
              <form onSubmit={handleCheck4D} className="flex gap-3">
                <input
                  type="text"
                  maxLength={4}
                  placeholder="Enter 4-digit number (e.g. 0842, 8823)"
                  value={fourDInput}
                  onChange={(e) => setFourDInput(e.target.value.replace(/\D/g, ''))}
                  className="flex-1 px-4 py-2.5 rounded-xl bg-navy-950 border border-slate-700 text-gold-300 font-mono text-lg font-black tracking-widest placeholder-slate-600 focus:outline-none focus:border-gold-500"
                />
                <button
                  type="submit"
                  disabled={!/^\d{4}$/.test(fourDInput.trim()) || loading4D}
                  className="px-6 py-2.5 rounded-xl bg-gold-500 hover:bg-gold-400 disabled:opacity-40 text-navy-950 font-bold text-xs uppercase shadow-gold-glow transition-all"
                >
                  {loading4D ? 'Checking...' : 'Check 4D'}
                </button>
              </form>

              {fourDResults && (
                <div className="mt-4 pt-4 border-t border-slate-800 space-y-3 animate-fadeIn">
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <Trophy className="w-4 h-4 text-gold-400" />
                      Past Prize Hits for <span className="font-mono text-gold-300">"{fourDResults.number}"</span>
                    </h4>
                    <span className="text-xs text-slate-400">{fourDResults.hitCount} Total Hits</span>
                  </div>

                  {fourDResults.hitCount === 0 ? (
                    <div className="p-4 rounded-xl bg-navy-950 border border-slate-800 text-center text-xs text-slate-400">
                      This 4D number has not won 1st, 2nd, 3rd, Starter, or Consolation in verified recorded history.
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-56 overflow-y-auto">
                      {fourDResults.history.map((h, i) => (
                        <div key={i} className="p-3 rounded-xl bg-navy-950 border border-slate-800 flex items-center justify-between text-xs">
                          <div>
                            <span className="font-bold text-gold-400">Draw #{h.drawNumber}</span>
                            <span className="text-slate-400 ml-2">({h.drawDate})</span>
                          </div>
                          <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold border ${
                            h.prizeType.includes('1st') ? 'bg-gold-500/20 text-gold-300 border-gold-500/40' :
                            (h.prizeType.includes('2nd') ? 'bg-slate-700 text-slate-200 border-slate-600' :
                            'bg-slate-800 text-slate-400 border-slate-700')
                          }`}>
                            {h.prizeType}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

        </div>
      </div>
    </div>
  );
}

