import React, { useState, useEffect } from 'react';
import { 
  Bar, 
  Doughnut, 
  Line 
} from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';
import { 
  Flame, 
  Snowflake, 
  TrendingUp, 
  BarChart2, 
  Sliders, 
  ShieldCheck, 
  Info,
  Clock,
  ArrowUpDown
} from 'lucide-react';
import { api } from '../services/api';

// Register ChartJS modules
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  ArcElement,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

export default function TotoAnalysis() {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sortField, setSortField] = useState('number'); // number, mainCount, currentGap, hotScore
  const [sortAsc, setSortAsc] = useState(true);
  const [filterStatus, setFilterStatus] = useState('ALL'); // ALL, HOT, COLD, NORMAL

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    setLoading(true);
    try {
      const res = await api.getTotoStats();
      if (res.success) {
        setStats(res);
      }
    } catch (e) {
      console.error('Failed to load TOTO stats:', e);
    } finally {
      setLoading(false);
    }
  };

  if (loading || !stats) {
    return (
      <div className="py-20 flex flex-col items-center justify-center gap-3">
        <div className="w-10 h-10 border-4 border-gold-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-sm font-semibold text-slate-300">Computing AI Mathematical Statistics (1-49)...</p>
      </div>
    );
  }

  // 1. Chart Data: 1-49 Frequency
  const frequencyChartData = {
    labels: stats.numbers.map(n => n.number.toString()),
    datasets: [
      {
        label: 'Historical Hit Count',
        data: stats.numbers.map(n => n.mainCount),
        backgroundColor: stats.numbers.map(n => 
          n.status === 'HOT' ? '#ef4444' : (n.status === 'COLD' ? '#06b6d4' : '#f59e0b')
        ),
        borderColor: stats.numbers.map(n => 
          n.status === 'HOT' ? '#b91c1c' : (n.status === 'COLD' ? '#0891b2' : '#d97706')
        ),
        borderWidth: 1,
        borderRadius: 4
      }
    ]
  };

  const frequencyChartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        callbacks: {
          label: (ctx) => {
            const numObj = stats.numbers[ctx.dataIndex];
            return `Count: ${numObj.mainCount} (${numObj.frequencyPct}%) | Gap: ${numObj.currentGap} draws | Status: ${numObj.status}`;
          }
        }
      }
    },
    scales: {
      x: {
        grid: { color: 'rgba(255, 255, 255, 0.05)' },
        ticks: { color: '#94a3b8', font: { size: 10 } }
      },
      y: {
        grid: { color: 'rgba(255, 255, 255, 0.05)' },
        ticks: { color: '#94a3b8', font: { size: 11 } }
      }
    }
  };

  // 2. Chart Data: Odd vs Even
  const oddEvenPatterns = Object.keys(stats.oddEvenAnalysis);
  const oddEvenActualData = oddEvenPatterns.map(p => stats.oddEvenAnalysis[p].actualPct);
  const oddEvenTheorData = oddEvenPatterns.map(p => stats.oddEvenAnalysis[p].theoreticalPct);

  const oddEvenChartData = {
    labels: oddEvenPatterns,
    datasets: [
      {
        label: 'Actual Draw %',
        data: oddEvenActualData,
        backgroundColor: '#f59e0b',
        borderRadius: 4
      },
      {
        label: 'Theoretical %',
        data: oddEvenTheorData,
        backgroundColor: '#64748b',
        borderRadius: 4
      }
    ]
  };

  // 3. Chart Data: High vs Low
  const highLowKeys = Object.keys(stats.highLowAnalysis);
  const highLowChartData = {
    labels: highLowKeys,
    datasets: [
      {
        data: highLowKeys.map(k => stats.highLowAnalysis[k].count),
        backgroundColor: [
          '#f59e0b', '#3b82f6', '#10b981', '#8b5cf6', '#ec4899', '#f97316', '#64748b'
        ],
        borderWidth: 0
      }
    ]
  };

  // 4. Chart Data: Sum Ranges Bell Curve
  const sumRangeKeys = Object.keys(stats.sumAnalysis.ranges);
  const sumChartData = {
    labels: sumRangeKeys,
    datasets: [
      {
        label: 'Draws in Range',
        data: sumRangeKeys.map(k => stats.sumAnalysis.ranges[k]),
        backgroundColor: 'rgba(245, 158, 11, 0.25)',
        borderColor: '#f59e0b',
        borderWidth: 2,
        fill: true,
        tension: 0.4,
        pointBackgroundColor: '#fbbf24'
      }
    ]
  };

  // Table filtering and sorting
  let filteredNumbers = [...stats.numbers];
  if (filterStatus !== 'ALL') {
    filteredNumbers = filteredNumbers.filter(n => n.status === filterStatus);
  }

  filteredNumbers.sort((a, b) => {
    let valA = a[sortField];
    let valB = b[sortField];
    if (sortAsc) return valA > valB ? 1 : -1;
    return valA < valB ? 1 : -1;
  });

  const handleSort = (field) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false); // default descending
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Title & Chi-Square Header */}
      <div className="bg-navy-900 border border-slate-800 rounded-2xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
              <BarChart2 className="w-6 h-6 text-gold-400" />
              TOTO AI Deep Statistical Engine
            </h2>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3" />
              Verified Authentic Data
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Analyzing {stats.totalDraws} verified historical draws (total {stats.totalDraws * 6} winning numbers drawn).
          </p>
        </div>

        {/* Statistical Test Badge */}
        <div className="bg-navy-950/80 border border-gold-500/30 rounded-xl p-3 flex items-center gap-3">
          <Info className="w-5 h-5 text-gold-400 flex-shrink-0" />
          <div className="text-[11px] text-slate-300 leading-tight">
            <span className="font-bold text-gold-300">Chi-Square Test Stat: {stats.chiSquare.statistic}</span> (df=48)
            <div className="text-slate-400 text-[10px]">Confirms normal distribution with expected variance.</div>
          </div>
        </div>
      </div>

      {/* 1. FREQUENCY HISTOGRAM CHART (1-49) */}
      <div className="bg-navy-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <span>Historical Number Frequency (1 to 49)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Theoretical uniform expectation per number: <strong className="text-gold-400">~{stats.numbers[0]?.expectedCount} hits</strong> ({((6/49)*100).toFixed(2)}% occurrence probability).
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-red-500 inline-block"></span>
              <span className="text-slate-300">Hot (Recent Momentum)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-cyan-500 inline-block"></span>
              <span className="text-slate-300">Cold (Overdue Gap)</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-amber-500 inline-block"></span>
              <span className="text-slate-300">Normal</span>
            </div>
          </div>
        </div>

        <div className="h-72 w-full">
          <Bar data={frequencyChartData} options={frequencyChartOptions} />
        </div>
      </div>

      {/* 2. THREE-PANEL ADVANCED CHARTS: ODD/EVEN, HIGH/LOW, SUM BELL CURVE */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Panel A: Odd vs Even Distribution */}
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                Odd / Even Ratio Breakdown
              </h4>
            </div>
            <p className="text-[11px] text-slate-400 mb-4">
              Actual vs Theoretical binomial probability in 6 numbers.
            </p>
            <div className="h-56">
              <Bar 
                data={oddEvenChartData} 
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { position: 'top', labels: { color: '#94a3b8', font: { size: 10 } } } },
                  scales: {
                    x: { ticks: { color: '#94a3b8', font: { size: 10 } } },
                    y: { ticks: { color: '#94a3b8', font: { size: 10 } } }
                  }
                }} 
              />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 mt-3 border-t border-slate-800/80 pt-2">
            💡 Notice that 3O-3E, 4O-2E, and 2O-4E represent over 80% of all winning combinations.
          </p>
        </div>

        {/* Panel B: High vs Low Ratio */}
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-blue-400" />
                Low (1-24) vs High (25-49)
              </h4>
            </div>
            <p className="text-[11px] text-slate-400 mb-4">
              Historical ratio proportion per draw.
            </p>
            <div className="h-56 flex items-center justify-center">
              <Doughnut 
                data={highLowChartData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: {
                    legend: { position: 'right', labels: { color: '#cbd5e1', font: { size: 10 } } }
                  }
                }}
              />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 mt-3 border-t border-slate-800/80 pt-2">
            💡 Balanced 3L-3H and 2L-4H / 4L-2H make up the vast majority of historical draws.
          </p>
        </div>

        {/* Panel C: Sum Range Distribution (Bell Curve) */}
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                <BarChart2 className="w-4 h-4 text-gold-400" />
                Sum Distribution Curve
              </h4>
            </div>
            <p className="text-[11px] text-slate-400 mb-4">
              Mean: <strong className="text-gold-300">{stats.sumAnalysis.averageSum}</strong> (Expected: 150.0).
            </p>
            <div className="h-56">
              <Line 
                data={sumChartData}
                options={{
                  responsive: true,
                  maintainAspectRatio: false,
                  plugins: { legend: { display: false } },
                  scales: {
                    x: { ticks: { color: '#94a3b8', font: { size: 9 } } },
                    y: { ticks: { color: '#94a3b8', font: { size: 10 } } }
                  }
                }}
              />
            </div>
          </div>
          <p className="text-[10px] text-slate-500 mt-3 border-t border-slate-800/80 pt-2">
            💡 Combinations with sums outside 110-190 occur in less than 15% of historical draws.
          </p>
        </div>

      </div>

      {/* 3. NUMBER GAP & FREQUENCY TABLE (1 TO 49) */}
      <div className="bg-navy-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-gold-400" />
              <span>Full Number Matrix (1 to 49)</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Click headers to sort by Frequency, Current Gap, Average Interval, or Hot Score.
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 bg-navy-950 p-1 rounded-xl border border-slate-800">
            {['ALL', 'HOT', 'COLD', 'NORMAL'].map((st) => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  filterStatus === st
                    ? 'bg-gold-500 text-navy-950 shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {st}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto max-h-[500px]">
          <table className="w-full text-left text-xs">
            <thead className="sticky top-0 bg-navy-950 text-slate-400 uppercase tracking-wider text-[11px] font-semibold border-b border-slate-800 z-10">
              <tr>
                <th 
                  onClick={() => handleSort('number')}
                  className="py-3 px-4 cursor-pointer hover:text-gold-300"
                >
                  <div className="flex items-center gap-1">
                    <span>Number</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th 
                  onClick={() => handleSort('mainCount')}
                  className="py-3 px-4 cursor-pointer hover:text-gold-300"
                >
                  <div className="flex items-center gap-1">
                    <span>Hit Count (Main)</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4">Occurrence %</th>
                <th className="py-3 px-4">Add'l Count</th>
                <th 
                  onClick={() => handleSort('currentGap')}
                  className="py-3 px-4 cursor-pointer hover:text-gold-300"
                >
                  <div className="flex items-center gap-1">
                    <span>Current Gap (Draws)</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th 
                  onClick={() => handleSort('avgGap')}
                  className="py-3 px-4 cursor-pointer hover:text-gold-300"
                >
                  <div className="flex items-center gap-1">
                    <span>Avg Gap</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4">Max Drought</th>
                <th 
                  onClick={() => handleSort('hotScore')}
                  className="py-3 px-4 cursor-pointer hover:text-gold-300"
                >
                  <div className="flex items-center gap-1">
                    <span>Hot Score</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-medium">
              {filteredNumbers.map((row) => (
                <tr key={row.number} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-2.5 px-4">
                    <span className="w-8 h-8 rounded-full bg-slate-800 border border-gold-500/40 text-gold-300 font-extrabold text-xs flex items-center justify-center">
                      {row.number}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 font-mono font-bold text-white">
                    {row.mainCount}
                  </td>
                  <td className="py-2.5 px-4 font-mono text-slate-300">
                    {row.frequencyPct}%
                  </td>
                  <td className="py-2.5 px-4 font-mono text-rose-300">
                    {row.additionalCount}
                  </td>
                  <td className="py-2.5 px-4 font-mono font-bold">
                    <span className={row.currentGap >= 12 ? 'text-cyan-400' : (row.currentGap <= 2 ? 'text-red-400' : 'text-slate-300')}>
                      {row.currentGap} {row.currentGap === 0 ? '(Just Hit)' : 'draws'}
                    </span>
                  </td>
                  <td className="py-2.5 px-4 font-mono text-slate-400">
                    {row.avgGap}
                  </td>
                  <td className="py-2.5 px-4 font-mono text-slate-400">
                    {row.maxGap} draws
                  </td>
                  <td className="py-2.5 px-4 font-mono font-semibold text-gold-300">
                    {row.hotScore}
                  </td>
                  <td className="py-2.5 px-4 text-center">
                    {row.status === 'HOT' && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-red-500/20 text-red-300 border border-red-500/30">
                        <Flame className="w-3 h-3" /> HOT
                      </span>
                    )}
                    {row.status === 'COLD' && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                        <Snowflake className="w-3 h-3" /> COLD
                      </span>
                    )}
                    {row.status === 'NORMAL' && (
                      <span className="text-slate-500 text-[11px] font-semibold">
                        Normal
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}

