import React, { useState } from 'react';
import { 
  Cpu, 
  Dice5, 
  Flame, 
  Snowflake, 
  Users, 
  CopyCheck, 
  Star, 
  Sparkles, 
  BookmarkPlus, 
  Copy, 
  Check, 
  RefreshCw 
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function FourDGenerator() {
  const { addFavourite } = useAuth();
  const [mode, setMode] = useState('ai_statistical');
  const [lineCount, setLineCount] = useState(3);
  const [favouriteInput, setFavouriteInput] = useState('');
  const [results, setResults] = useState([]);
  const [generating, setGenerating] = useState(false);
  const [savedIndex, setSavedIndex] = useState(null);
  const [copiedIndex, setCopiedIndex] = useState(null);

  // 7 4D Generator Modes strictly adhering to requirements
  const generatorModes = [
    {
      id: 'ai_statistical',
      label: 'AI Statistical Generator',
      icon: Cpu,
      badge: 'Smart Engine',
      desc: 'Blends position-by-position frequency, popular front/back pairs, and optimal ABCD/AABC digit distribution.'
    },
    {
      id: 'random',
      label: 'Random 4D Generator',
      icon: Dice5,
      badge: '0000 - 9999',
      desc: 'Uniform pseudo-random generation across all 10,000 potential 4D numbers.'
    },
    {
      id: 'hot',
      label: 'Hot Number Generator',
      icon: Flame,
      badge: 'High Frequency',
      desc: 'Constructs numbers predominantly using the most frequently appearing digits and pairs.'
    },
    {
      id: 'cold',
      label: 'Cold Number Generator',
      icon: Snowflake,
      badge: 'Overdue Mean-Reversion',
      desc: 'Synthesizes numbers using historically dormant or least frequent digits across 4 positions.'
    },
    {
      id: 'pair',
      label: 'Pair Number Generator',
      icon: Users,
      badge: 'Pair Focused',
      desc: 'Selects high-momentum front pairs (1st & 2nd) and back pairs (3rd & 4th).'
    },
    {
      id: 'double_digit',
      label: 'Double Digit Generator',
      icon: CopyCheck,
      badge: 'AABC / AABB',
      desc: 'Guarantees repeated digit structures (such as double digit 8824 or double pair 2299).'
    },
    {
      id: 'favourite',
      label: 'Favourite Number Generator',
      icon: Star,
      badge: 'Custom Seed',
      desc: 'Enter 1 to 4 lucky digits; the AI completes or optimizes into a winning-format 4D number.'
    }
  ];

  const handleGenerate = async () => {
    setGenerating(true);
    setSavedIndex(null);
    setCopiedIndex(null);

    try {
      const res = await api.generateFourD(mode, lineCount, favouriteInput);
      if (res.success) {
        setResults(res.combinations);
        confetti({
          particleCount: 65,
          spread: 65,
          origin: { y: 0.65 },
          colors: ['#06b6d4', '#f59e0b', '#ffffff']
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setGenerating(false);
    }
  };

  const handleSave = async (combo, idx) => {
    const res = await addFavourite(
      '4d',
      [combo.number],
      `4D ${combo.mode.toUpperCase()} (Line ${idx+1})`,
      `Pattern: ${combo.pattern} | Front: ${combo.frontPair} | Back: ${combo.backPair}`
    );
    if (res.success) {
      setSavedIndex(idx);
      setTimeout(() => setSavedIndex(null), 3000);
    } else {
      alert(res.error || 'Please sign in to save favourite combinations.');
    }
  };

  const handleCopy = (combo, idx) => {
    navigator.clipboard.writeText(combo.number);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      
      {/* Title */}
      <div className="bg-navy-900 border border-slate-800 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-white tracking-tight flex items-center gap-2">
            <Cpu className="w-6 h-6 text-gold-400" />
            Singapore 4D Multi-Model AI Generator
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Choose from 7 distinct mathematical generation paradigms. Every output is strictly 4 digits with leading zeros (0000–9999).
          </p>
        </div>

        <div className="flex items-center gap-2 bg-navy-950 p-1.5 rounded-xl border border-slate-800">
          <span className="text-xs font-semibold text-slate-400 pl-2">Lines:</span>
          {[1, 3, 5, 10].map(cnt => (
            <button
              key={cnt}
              onClick={() => setLineCount(cnt)}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                lineCount === cnt
                  ? 'bg-gold-500 text-navy-950 shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cnt}
            </button>
          ))}
        </div>
      </div>

      {/* 7 Generator Modes Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {generatorModes.map(m => {
          const Icon = m.icon;
          const isSelected = mode === m.id;
          return (
            <div
              key={m.id}
              onClick={() => setMode(m.id)}
              className={`cursor-pointer rounded-2xl p-5 border transition-all duration-200 flex flex-col justify-between ${
                isSelected
                  ? 'bg-navy-850 border-gold-500 shadow-gold-glow scale-[1.02]'
                  : 'bg-navy-900/80 border-slate-800 hover:border-slate-700 hover:bg-navy-850/60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                    isSelected ? 'bg-gold-500 text-navy-950' : 'bg-slate-800 text-slate-300'
                  }`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border ${
                    isSelected
                      ? 'bg-gold-500/20 text-gold-300 border-gold-500/40'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}>
                    {m.badge}
                  </span>
                </div>
                <h3 className="font-bold text-white text-sm">{m.label}</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{m.desc}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                <span className={isSelected ? 'text-gold-400 font-semibold' : 'text-slate-500'}>
                  {isSelected ? '✓ Selected' : 'Click to select'}
                </span>
                <span className="font-mono text-slate-500">4-Digits</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* If Favourite Mode Selected */}
      {mode === 'favourite' && (
        <div className="bg-navy-900 border border-slate-800 rounded-2xl p-6 shadow-xl animate-fadeIn">
          <div className="flex items-center gap-2 mb-2">
            <Star className="w-4 h-4 text-gold-400 fill-gold-400" />
            <h4 className="text-sm font-bold text-white">
              Enter 1 to 4 Lucky Digits (e.g. "88" or "128")
            </h4>
          </div>
          <p className="text-xs text-slate-400 mb-4">
            If you provide fewer than 4 digits, the AI statistical engine will complete the remaining positions with high-probability digits.
          </p>
          <div className="max-w-xs">
            <input 
              type="text"
              maxLength={4}
              placeholder="e.g. 88, 38, or 789"
              value={favouriteInput}
              onChange={(e) => setFavouriteInput(e.target.value.replace(/\D/g, ''))}
              className="w-full px-4 py-2.5 rounded-xl bg-navy-950 border border-gold-500/40 text-gold-300 font-mono text-lg font-bold tracking-widest placeholder-slate-600 focus:outline-none focus:border-gold-400"
            />
          </div>
        </div>
      )}

      {/* Generate Action Button */}
      <div className="flex justify-center pt-2">
        <button
          onClick={handleGenerate}
          disabled={generating}
          className="flex items-center justify-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-gold-500 via-gold-400 to-amber-600 hover:from-gold-400 hover:to-amber-500 text-navy-950 font-black text-sm uppercase tracking-wider shadow-gold-glow-lg transform hover:-translate-y-0.5 transition-all"
        >
          {generating ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
          <span>{generating ? 'Simulating 4D Numbers...' : `Generate ${lineCount} 4D Combinations`}</span>
        </button>
      </div>

      {/* Generated Results */}
      {results.length > 0 && (
        <div className="space-y-4 pt-4 animate-fadeIn">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Check className="w-5 h-5 text-emerald-400" />
              Generated 4D Numbers ({results.length} Numbers)
            </h3>
            <span className="text-xs text-slate-400">Strictly 4 digits (0000–9999) with leading zeros</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {results.map((combo, idx) => (
              <div 
                key={idx}
                className="bg-navy-900 border border-gold-500/30 rounded-2xl p-5 shadow-xl flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[11px] font-mono font-bold text-slate-400">
                      Line #{idx + 1}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-gold-300 border border-gold-500/30">
                      {combo.pattern}
                    </span>
                  </div>

                  {/* 4D Digital Number */}
                  <div className="py-4 text-center bg-navy-950 rounded-xl border border-slate-800">
                    <span className="font-mono text-4xl font-black tracking-widest text-gold-400 drop-shadow">
                      {combo.number}
                    </span>
                  </div>

                  {/* Pair Breakdown */}
                  <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="bg-navy-950/80 p-1.5 rounded-lg border border-slate-800">
                      <div className="text-[9px] text-slate-500">Front Pair</div>
                      <div className="font-mono font-bold text-cyan-300">{combo.frontPair}</div>
                    </div>
                    <div className="bg-navy-950/80 p-1.5 rounded-lg border border-slate-800">
                      <div className="text-[9px] text-slate-500">Back Pair</div>
                      <div className="font-mono font-bold text-cyan-300">{combo.backPair}</div>
                    </div>
                    <div className="bg-navy-950/80 p-1.5 rounded-lg border border-slate-800">
                      <div className="text-[9px] text-slate-500">Digit Sum</div>
                      <div className="font-mono font-bold text-amber-300">{combo.digitSum}</div>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-gold-400 font-semibold">
                    AI Score: {combo.aiScore}%
                  </span>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleCopy(combo, idx)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                      title="Copy number"
                    >
                      {copiedIndex === idx ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                    <button
                      onClick={() => handleSave(combo, idx)}
                      className="p-1.5 rounded-lg bg-navy-800 hover:bg-gold-500 hover:text-navy-950 text-gold-400 border border-gold-500/30 transition-all"
                      title="Save to Favourites"
                    >
                      {savedIndex === idx ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <BookmarkPlus className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}

