import React, { useState } from 'react';
import { 
  Sparkles, 
  BarChart3, 
  Cpu, 
  Search, 
  History, 
  Bookmark, 
  ShieldAlert, 
  User, 
  LogOut, 
  LogIn, 
  Layers, 
  Menu, 
  X,
  ChevronDown
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Navbar({ 
  activeGame, 
  setActiveGame, 
  activeTab, 
  setActiveTab, 
  onOpenAuth, 
  onOpenFavourites,
  onOpenChecker 
}) {
  const { user, logout, isAdmin, favourites } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Layers },
    { id: 'analysis', label: 'AI Statistics', icon: BarChart3 },
    { id: 'generators', label: 'AI Generators', icon: Cpu },
    { id: 'history', label: 'Draw History', icon: History }
  ];

  return (
    <header className="sticky top-0 z-40 bg-navy-900/95 backdrop-blur-md border-b border-gold-500/20 shadow-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          
          {/* Brand Logo & Tag */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-gold-400 via-gold-600 to-amber-700 flex items-center justify-center shadow-gold-glow border border-gold-300/40 transform hover:rotate-6 transition-transform">
              <span className="text-xl sm:text-2xl font-black text-navy-950">👑</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg sm:text-xl font-extrabold tracking-tight text-white flex items-center gap-1.5">
                  TOTO <span className="gold-gradient-text">AI MASTER</span>
                </span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-red-600/30 text-red-200 border border-red-500/40">
                  SG 🇸🇬
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Singapore Pools TOTO + 4D AI Intelligence
              </p>
            </div>
          </div>

          {/* Center: Game Mode Switcher (TOTO vs 4D) */}
          <div className="flex items-center bg-navy-950/80 p-1 rounded-xl border border-slate-700/60 shadow-inner">
            <button
              onClick={() => { setActiveGame('toto'); if(activeTab === 'admin') setActiveTab('dashboard'); }}
              className={`flex items-center gap-2 px-3 sm:px-5 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-bold transition-all duration-200 ${
                activeGame === 'toto'
                  ? 'bg-gradient-to-r from-gold-500 to-amber-600 text-navy-950 shadow-gold-glow scale-102'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-navy-950 inline-block animate-ping" style={{ display: activeGame === 'toto' ? 'inline-block' : 'none' }}></span>
              <span>SINGAPORE TOTO</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-navy-950/20 uppercase font-semibold">6/49</span>
            </button>
            <button
              onClick={() => { setActiveGame('4d'); if(activeTab === 'admin') setActiveTab('dashboard'); }}
              className={`flex items-center gap-2 px-3 sm:px-5 py-1.5 sm:py-2 rounded-lg text-xs sm:text-sm font-bold transition-all duration-200 ${
                activeGame === '4d'
                  ? 'bg-gradient-to-r from-gold-500 to-amber-600 text-navy-950 shadow-gold-glow scale-102'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
              }`}
            >
              <span className="w-2 h-2 rounded-full bg-navy-950 inline-block animate-ping" style={{ display: activeGame === '4d' ? 'inline-block' : 'none' }}></span>
              <span>SINGAPORE 4D</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded bg-navy-950/20 uppercase font-semibold">0000-9999</span>
            </button>
          </div>

          {/* Desktop Navigation Tabs */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                    isActive
                      ? 'text-gold-300 bg-gold-500/10 border border-gold-500/30 shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              );
            })}

            {/* Quick Check Tool */}
            <button
              onClick={onOpenChecker}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold text-emerald-400 hover:bg-emerald-500/10 border border-emerald-500/30 transition-all ml-1"
            >
              <Search className="w-3.5 h-3.5" />
              <span>Number Checker</span>
            </button>
          </nav>

          {/* Right Action Buttons */}
          <div className="flex items-center gap-2">
            
            {/* Favourites Button */}
            <button
              onClick={onOpenFavourites}
              className="relative p-2 sm:px-3 sm:py-2 rounded-lg bg-navy-850 hover:bg-navy-800 border border-gold-500/20 text-gold-400 hover:text-gold-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              title="My Saved Favourites"
            >
              <Bookmark className="w-4 h-4 fill-gold-400/20" />
              <span className="hidden sm:inline">Favourites</span>
              {favourites.length > 0 && (
                <span className="w-5 h-5 rounded-full bg-gold-500 text-navy-950 font-extrabold text-[10px] flex items-center justify-center">
                  {favourites.length}
                </span>
              )}
            </button>

            {/* Admin Badge/Button */}
            {isAdmin && (
              <button
                onClick={() => setActiveTab('admin')}
                className={`px-3 py-1.5 sm:py-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                  activeTab === 'admin'
                    ? 'bg-amber-500 text-navy-950 font-extrabold shadow-gold-glow'
                    : 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/40'
                }`}
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Admin Panel</span>
              </button>
            )}

            {/* User Profile / Auth Button */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 pl-2 pr-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-xs font-medium text-slate-200"
                >
                  <div className="w-6 h-6 rounded-full bg-gradient-to-r from-blue-500 to-indigo-600 text-white flex items-center justify-center font-bold text-[11px]">
                    {user.name ? user.name[0].toUpperCase() : 'U'}
                  </div>
                  <span className="max-w-[80px] sm:max-w-[110px] truncate">{user.name}</span>
                  <ChevronDown className="w-3 h-3 text-slate-400" />
                </button>

                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 rounded-xl bg-navy-900 border border-gold-500/20 shadow-2xl p-2 z-50">
                    <div className="px-3 py-2 border-b border-slate-800 text-xs">
                      <p className="font-semibold text-white">{user.name}</p>
                      <p className="text-slate-400 text-[11px] truncate">{user.email}</p>
                      <span className="inline-block mt-1 px-1.5 py-0.5 text-[9px] rounded font-bold uppercase bg-gold-500/10 text-gold-400 border border-gold-500/30">
                        {user.role}
                      </span>
                    </div>
                    {isAdmin && (
                      <button
                        onClick={() => { setActiveTab('admin'); setUserDropdownOpen(false); }}
                        className="w-full text-left px-3 py-2 text-xs font-medium text-amber-300 hover:bg-amber-500/10 rounded-lg flex items-center gap-2 mt-1"
                      >
                        <ShieldAlert className="w-3.5 h-3.5" />
                        Admin Dashboard
                      </button>
                    )}
                    <button
                      onClick={() => { logout(); setUserDropdownOpen(false); }}
                      className="w-full text-left px-3 py-2 text-xs font-medium text-rose-400 hover:bg-rose-500/10 rounded-lg flex items-center gap-2 mt-1"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-gradient-to-r from-gold-500 to-amber-600 hover:from-gold-400 hover:to-amber-500 text-navy-950 font-bold text-xs shadow-gold-glow transition-all"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Sign In</span>
              </button>
            )}

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-lg text-slate-300 hover:text-white bg-slate-800/60"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Navigation */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-800 py-3 px-2 flex flex-col gap-1 bg-navy-950/90 rounded-b-xl animate-fadeIn">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id); setMobileMenuOpen(false); }}
                  className={`flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-medium w-full text-left ${
                    activeTab === item.id ? 'bg-gold-500/20 text-gold-300 font-bold' : 'text-slate-300'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
            <button
              onClick={() => { onOpenChecker(); setMobileMenuOpen(false); }}
              className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-medium text-emerald-400 w-full text-left"
            >
              <Search className="w-4 h-4" />
              <span>Number Checker</span>
            </button>
            {isAdmin && (
              <button
                onClick={() => { setActiveTab('admin'); setMobileMenuOpen(false); }}
                className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-xs font-medium text-amber-300 w-full text-left"
              >
                <ShieldAlert className="w-4 h-4" />
                <span>Admin Panel</span>
              </button>
            )}
          </div>
        )}
      </div>
    </header>
  );
}

