import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import Navbar from './components/Navbar';
import DisclaimerBanner from './components/DisclaimerBanner';
import TotoDashboard from './components/TotoDashboard';
import TotoAnalysis from './components/TotoAnalysis';
import TotoGenerator from './components/TotoGenerator';
import FourDDashboard from './components/FourDDashboard';
import FourDAnalysis from './components/FourDAnalysis';
import FourDGenerator from './components/FourDGenerator';
import AdminPanel from './components/AdminPanel';
import NumberCheckerModal from './components/NumberCheckerModal';
import FavouritesModal from './components/FavouritesModal';
import AuthModal from './components/AuthModal';
import { 
  ShieldCheck, 
  Heart, 
  ExternalLink, 
  Sparkles, 
  AlertTriangle 
} from 'lucide-react';

function MainApp() {
  const [activeGame, setActiveGame] = useState('toto'); // 'toto' | '4d'
  const [activeTab, setActiveTab] = useState('dashboard'); // 'dashboard' | 'analysis' | 'generators' | 'history' | 'admin'
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [favouritesModalOpen, setFavouritesModalOpen] = useState(false);
  const [checkerModalOpen, setCheckerModalOpen] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-navy-950 text-slate-100">
      
      {/* 1. TOP NAVBAR */}
      <Navbar
        activeGame={activeGame}
        setActiveGame={setActiveGame}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenAuth={() => setAuthModalOpen(true)}
        onOpenFavourites={() => setFavouritesModalOpen(true)}
        onOpenChecker={() => setCheckerModalOpen(true)}
      />

      {/* 2. RESPONSIBLE GAMING DISCLAIMER BANNER */}
      <DisclaimerBanner />

      {/* 3. MAIN WORKSPACE CONTENT */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        
        {/* Admin Dashboard view */}
        {activeTab === 'admin' && (
          <AdminPanel />
        )}

        {/* Dashboard View */}
        {activeTab === 'dashboard' && (
          activeGame === 'toto' ? (
            <TotoDashboard 
              onNavigateToAnalysis={() => setActiveTab('analysis')}
              onNavigateToGenerator={() => setActiveTab('generators')}
            />
          ) : (
            <FourDDashboard 
              onNavigateToAnalysis={() => setActiveTab('analysis')}
              onNavigateToGenerator={() => setActiveTab('generators')}
            />
          )
        )}

        {/* AI Statistics & Analysis View */}
        {activeTab === 'analysis' && (
          activeGame === 'toto' ? (
            <TotoAnalysis />
          ) : (
            <FourDAnalysis />
          )
        )}

        {/* AI Generators View */}
        {activeTab === 'generators' && (
          activeGame === 'toto' ? (
            <TotoGenerator />
          ) : (
            <FourDGenerator />
          )
        )}

        {/* Historical Explorer View */}
        {activeTab === 'history' && (
          activeGame === 'toto' ? (
            <TotoDashboard 
              onNavigateToAnalysis={() => setActiveTab('analysis')}
              onNavigateToGenerator={() => setActiveTab('generators')}
            />
          ) : (
            <FourDDashboard 
              onNavigateToAnalysis={() => setActiveTab('analysis')}
              onNavigateToGenerator={() => setActiveTab('generators')}
            />
          )
        )}

      </main>

      {/* 4. FOOTER */}
      <footer className="mt-auto border-t border-slate-800/80 bg-navy-900/95 py-8 px-4 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gold-500/20 text-gold-400 flex items-center justify-center font-black border border-gold-500/40">
              👑
            </div>
            <div>
              <p className="font-bold text-white tracking-wide">
                TOTO AI MASTER <span className="text-[11px] font-normal text-slate-400">Singapore Lottery Intelligence</span>
              </p>
              <p className="text-[11px] text-slate-500">
                Official draw data verified against Singapore Pools historical records.
              </p>
            </div>
          </div>

          <div className="text-center md:text-right space-y-1">
            <p className="text-slate-400 flex items-center justify-center md:justify-end gap-1.5">
              <span>National Council on Problem Gambling Hotline: <strong>1800-6-668-668</strong></span>
            </p>
            <p className="text-[11px] text-slate-500">
              Play Responsibly • Strictly 18+ • Historical frequency does not guarantee future results.
            </p>
          </div>
        </div>
      </footer>

      {/* MODALS */}
      <AuthModal 
        isOpen={authModalOpen} 
        onClose={() => setAuthModalOpen(false)} 
      />

      <FavouritesModal 
        isOpen={favouritesModalOpen} 
        onClose={() => setFavouritesModalOpen(false)} 
      />

      <NumberCheckerModal 
        isOpen={checkerModalOpen} 
        onClose={() => setCheckerModalOpen(false)} 
      />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}

