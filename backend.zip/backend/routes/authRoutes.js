const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');

router.post('/register', authController.register);
router.post('/login', authController.login);
router.get('/me', authController.authenticate, authController.getMe);
router.get('/favourites', authController.authenticate, authController.getFavourites);
router.post('/favourites', authController.authenticate, authController.addFavourite);
router.delete('/favourites/:id', authController.authenticate, authController.deleteFavourite);

module.exports = router;

