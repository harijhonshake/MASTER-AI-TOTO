const express = require('express');
const router = express.Router();
const adminController = require('../controllers/adminController');
const { authenticate, requireAdmin } = require('../controllers/authController');

// All admin routes require valid JWT and admin role
router.use(authenticate, requireAdmin);

// TOTO management
router.post('/toto', adminController.createTotoDraw);
router.put('/toto/:id', adminController.updateTotoDraw);
router.delete('/toto/:id', adminController.deleteTotoDraw);

// 4D management
router.post('/4d', adminController.createFourDDraw);
router.put('/4d/:id', adminController.updateFourDDraw);
router.delete('/4d/:id', adminController.deleteFourDDraw);

// Bulk import & sync
router.post('/import', adminController.importData);
router.post('/sync', adminController.triggerSync);

// Users & system analytics
router.get('/users', adminController.getUsers);
router.put('/users/:id/role', adminController.updateUserRole);
router.get('/analytics', adminController.getSystemAnalytics);

module.exports = router;

