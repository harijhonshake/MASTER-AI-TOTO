const express = require('express');
const router = express.Router();
const aiController = require('../controllers/aiController');

router.post('/generate/toto', aiController.generateToto);
router.post('/generate/4d', aiController.generateFourD);
router.get('/report', aiController.getExecutiveReport);

module.exports = router;

