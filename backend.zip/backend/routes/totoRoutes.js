const express = require('express');
const router = express.Router();
const totoController = require('../controllers/totoController');

router.get('/latest', totoController.getLatest);
router.get('/history', totoController.getAll);
router.get('/stats', totoController.getStats);
router.post('/check', totoController.checkNumbers);

module.exports = router;

