const express = require('express');
const router = express.Router();
const fourDController = require('../controllers/fourDController');

router.get('/latest', fourDController.getLatest);
router.get('/history', fourDController.getAll);
router.get('/stats', fourDController.getStats);
router.post('/check', fourDController.checkNumber);

module.exports = router;

