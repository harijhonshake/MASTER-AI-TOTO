"""
TOTO AI MASTER - AI Combinatorial Lottery Generators
Generates mathematically valid, simulated combinations for Singapore TOTO and 4D.
Strict constraints:
- TOTO: Exactly 6 unique integers (1-49) + 1 additional number.
- 4D: Exactly 4 digits with leading zeros (0000-9999).
"""
import sys
import json
import random
from collections import Counter

def generate_toto_combination(mode="ai_statistical", hot_numbers=None, cold_numbers=None, favourites=None, count=1):
    """
    Generate TOTO combinations.
    Modes:
      - ai_statistical: weighted hot/cold, odd/even balance (3:3 or 4:2), high/low balance, sum 115-185
      - random: pure random pick
      - hot: heavy weighting on hot numbers
      - cold: heavy weighting on cold/overdue numbers
      - favourites: includes user favourites, fills rest statistically
    """
    if hot_numbers is None:
        hot_numbers = [7, 12, 19, 23, 28, 34, 41, 45, 48, 15]
    if cold_numbers is None:
        cold_numbers = [3, 9, 14, 21, 30, 37, 40, 44, 47, 2]
    if favourites is None:
        favourites = []

    results = []

    for _ in range(count):
        for attempt in range(100): # attempt to satisfy constraints
            picks = set()

            if mode == "random":
                picks = set(random.sample(range(1, 50), 6))
            elif mode == "hot":
                # Pick 4 from hot, 2 from remaining
                h_picks = random.sample(hot_numbers, min(4, len(hot_numbers)))
                picks.update(h_picks)
                remaining = [x for x in range(1, 50) if x not in picks]
                picks.update(random.sample(remaining, 6 - len(picks)))
            elif mode == "cold":
                # Pick 3 from cold, 3 from remaining
                c_picks = random.sample(cold_numbers, min(3, len(cold_numbers)))
                picks.update(c_picks)
                remaining = [x for x in range(1, 50) if x not in picks]
                picks.update(random.sample(remaining, 6 - len(picks)))
            elif mode == "favourites":
                # Include valid favourite numbers (1-49)
                valid_favs = [f for f in favourites if 1 <= f <= 49][:5]
                picks.update(valid_favs)
                remaining = [x for x in range(1, 50) if x not in picks]
                picks.update(random.sample(remaining, 6 - len(picks)))
            else: # ai_statistical
                # Balanced probability pool:
                # 3 from hot, 1 from cold, 2 from rest
                h_pool = [x for x in hot_numbers if x not in picks]
                c_pool = [x for x in cold_numbers if x not in picks]
                picks.update(random.sample(h_pool, min(3, len(h_pool))))
                picks.update(random.sample(c_pool, min(1, len(c_pool))))
                remaining = [x for x in range(1, 50) if x not in picks]
                picks.update(random.sample(remaining, 6 - len(picks)))

            sorted_picks = sorted(list(picks))
            
            # Constraint check for ai_statistical
            if mode == "ai_statistical":
                total_sum = sum(sorted_picks)
                odds = sum(1 for x in sorted_picks if x % 2 != 0)
                highs = sum(1 for x in sorted_picks if x >= 25)
                # Optimal conditions: sum 115-185, odd/even 2 to 4, high/low 2 to 4
                if 110 <= total_sum <= 190 and 2 <= odds <= 4 and 2 <= highs <= 4:
                    break
            else:
                break

        sorted_picks = sorted(list(picks))
        # Additional number (must be unique from 6 winning numbers)
        avail_for_add = [x for x in range(1, 50) if x not in picks]
        add_num = random.choice(avail_for_add)

        odd_count = sum(1 for x in sorted_picks if x % 2 != 0)
        even_count = 6 - odd_count
        high_count = sum(1 for x in sorted_picks if x >= 25)
        low_count = 6 - high_count

        results.append({
            "numbers": sorted_picks,
            "additionalNumber": add_num,
            "mode": mode,
            "stats": {
                "sum": sum(sorted_picks),
                "oddEven": f"{odd_count}O-{even_count}E",
                "highLow": f"{low_count}L-{high_count}H",
                "aiConfidenceScore": round(random.uniform(78.5, 94.2), 1)
            }
        })

    return results

def generate_4d_combination(mode="ai_statistical", hot_digits=None, cold_digits=None, favourite="", count=1):
    """
    Generate 4D combinations (strictly 4 digits with leading zeros).
    Modes:
      1. ai_statistical: weighted position probability, high-frequency pattern (ABCD or AABC)
      2. random: pure random pick 0000-9999
      3. hot: picks from hot digits
      4. cold: picks from cold digits
      5. pair: generates based on popular front/back pairs
      6. double_digit: strictly generates AABC or AABB pattern
      7. favourite: incorporates user favourite digits
    """
    if hot_digits is None:
        hot_digits = [8, 3, 7, 2, 9]
    if cold_digits is None:
        cold_digits = [0, 4, 1, 5, 6]

    results = []

    for _ in range(count):
        digits = []

        if mode == "random":
            num = random.randint(0, 9999)
            formatted = f"{num:04d}"
        elif mode == "hot":
            # Pick all 4 digits from hot digits pool with slight noise
            pool = hot_digits * 3 + list(range(10))
            digits = [str(random.choice(pool)) for _ in range(4)]
            formatted = "".join(digits)
        elif mode == "cold":
            # Pick from cold digits pool
            pool = cold_digits * 3 + list(range(10))
            digits = [str(random.choice(pool)) for _ in range(4)]
            formatted = "".join(digits)
        elif mode == "pair":
            # Front pair + back pair
            popular_pairs = ["88", "28", "38", "19", "68", "99", "08", "33", "77", "12", "58", "49"]
            p1 = random.choice(popular_pairs)
            p2 = random.choice(popular_pairs)
            formatted = p1 + p2
        elif mode == "double_digit":
            # Form AABC or AABB
            d1 = str(random.choice(range(10)))
            d2 = str(random.choice([x for x in range(10) if str(x) != d1]))
            d3 = str(random.choice([x for x in range(10) if str(x) not in [d1, d2]]))
            if random.random() < 0.7:
                # AABC
                pattern_chars = [d1, d1, d2, d3]
            else:
                # AABB
                pattern_chars = [d1, d1, d2, d2]
            random.shuffle(pattern_chars)
            formatted = "".join(pattern_chars)
        elif mode == "favourite":
            clean_fav = "".join([c for c in str(favourite) if c.isdigit()])[:4]
            if len(clean_fav) == 4:
                formatted = clean_fav
            else:
                needed = 4 - len(clean_fav)
                tail = "".join([str(random.choice(range(10))) for _ in range(needed)])
                formatted = clean_fav + tail
        else: # ai_statistical
            # Balance position weightings:
            # Pick position 0-3 with frequent pattern ABCD or AABC
            if random.random() < 0.52:
                # ABCD: 4 unique digits with hot/balanced weight
                chosen = random.sample(range(10), 4)
                formatted = "".join([str(x) for x in chosen])
            else:
                # AABC: 1 double digit
                double_d = str(random.choice(hot_digits))
                other_ds = random.sample([str(x) for x in range(10) if str(x) != double_d], 2)
                chars = [double_d, double_d, other_ds[0], other_ds[1]]
                random.shuffle(chars)
                formatted = "".join(chars)

        # Classification of generated number
        counts = sorted(Counter(formatted).values(), reverse=True)
        pat_name = "Single (ABCD)"
        if counts == [2, 1, 1]:
            pat_name = "Double (AABC)"
        elif counts == [2, 2]:
            pat_name = "Double Pair (AABB)"
        elif counts == [3, 1]:
            pat_name = "Triple (AAAB)"
        elif counts == [4]:
            pat_name = "Quad (AAAA)"

        d_sum = sum(int(ch) for ch in formatted)

        results.append({
            "number": formatted,
            "mode": mode,
            "pattern": pat_name,
            "digitSum": d_sum,
            "frontPair": formatted[:2],
            "backPair": formatted[2:],
            "aiScore": round(random.uniform(82.0, 96.5), 1)
        })

    return results

if __name__ == "__main__":
    # Test generator execution
    t_res = generate_toto_combination(mode="ai_statistical", count=3)
    f_res = generate_4d_combination(mode="ai_statistical", count=3)
    print("TOTO sample:", json.dumps(t_res, indent=2))
    print("4D sample:", json.dumps(f_res, indent=2))

