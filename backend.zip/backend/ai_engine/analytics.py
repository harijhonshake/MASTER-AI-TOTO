"""
TOTO AI MASTER - Advanced Python AI Statistical Analysis Engine
Computes comprehensive statistical modeling, distributions, hot/cold patterns,
frequency deviations, chi-square tests, gap intervals, and combinatorial analysis
for Singapore TOTO and Singapore 4D.
"""
import sys
import json
import math
from collections import Counter, defaultdict

def analyze_toto(draws):
    """
    Complete statistical analysis of Singapore TOTO historical draws.
    draws: list of dicts with keys: drawNumber, drawDate, winningNumbers (6 nums), additionalNumber
    """
    total_draws = len(draws)
    if total_draws == 0:
        return {}

    # 1. Frequency of each number 1 to 49
    main_freq = Counter()
    add_freq = Counter()
    total_freq = Counter()
    
    # Track gaps (draws since last appearance)
    last_seen = {} # number -> index of draw (0 is oldest, total_draws-1 is newest)
    all_gaps = defaultdict(list)
    
    # Odd/Even & High/Low counts
    odd_even_dist = Counter()
    high_low_dist = Counter()
    sum_distribution = []
    consecutive_counts = 0
    decades_dist = Counter() # 1-9, 10-19, 20-29, 30-39, 40-49
    
    # Recent windows
    last_20_draws = draws[-20:] if total_draws >= 20 else draws
    last_50_draws = draws[-50:] if total_draws >= 50 else draws
    freq_last_20 = Counter()
    freq_last_50 = Counter()
    
    for d in last_20_draws:
        for n in d["winningNumbers"]:
            freq_last_20[n] += 1
            
    for d in last_50_draws:
        for n in d["winningNumbers"]:
            freq_last_50[n] += 1

    # Traverse chronologically
    for idx, d in enumerate(draws):
        win_nums = sorted(d["winningNumbers"])
        add_num = d.get("additionalNumber")
        
        # Main & additional frequency
        for n in win_nums:
            main_freq[n] += 1
            total_freq[n] += 1
            if n in last_seen:
                gap = idx - last_seen[n]
                all_gaps[n].append(gap)
            last_seen[n] = idx
            
        if add_num:
            add_freq[add_num] += 1
            total_freq[add_num] += 1
            
        # Odd / Even
        odds = sum(1 for n in win_nums if n % 2 != 0)
        evens = 6 - odds
        odd_even_dist[f"{odds}O-{evens}E"] += 1
        
        # High (25-49) / Low (1-24)
        highs = sum(1 for n in win_nums if n >= 25)
        lows = 6 - highs
        high_low_dist[f"{lows}L-{highs}H"] += 1
        
        # Sum
        s = sum(win_nums)
        sum_distribution.append(s)
        
        # Consecutive check
        has_consecutive = any(win_nums[i+1] == win_nums[i] + 1 for i in range(len(win_nums)-1))
        if has_consecutive:
            consecutive_counts += 1
            
        # Decades
        for n in win_nums:
            decade = min(4, (n - 1) // 10)
            decades_dist[decade] += 1

    # Expected frequency per number in 6-number draw
    expected_freq = (total_draws * 6) / 49.0
    
    # Chi-square goodness-of-fit test for 49 numbers
    chi_square_stat = 0.0
    number_stats = []
    
    for n in range(1, 50):
        c_main = main_freq[n]
        c_add = add_freq[n]
        c_total = total_freq[n]
        pct = (c_main / total_draws) * 100.0 if total_draws > 0 else 0
        diff = c_main - expected_freq
        chi_square_stat += (diff ** 2) / expected_freq
        
        # Current gap (distance from last appearance to total_draws)
        curr_gap = (total_draws - 1 - last_seen[n]) if n in last_seen else total_draws
        gaps_list = all_gaps[n]
        avg_gap = (sum(gaps_list) / len(gaps_list)) if gaps_list else expected_freq
        max_gap = max(gaps_list) if gaps_list else curr_gap
        
        # Hot/Cold score: combines all-time deviation, last 20 boost, and inverse gap
        hot_score = (freq_last_20[n] * 3.0) + (freq_last_50[n] * 1.5) + (c_main / total_draws * 10) - (curr_gap * 0.4)
        
        number_stats.append({
            "number": n,
            "mainCount": c_main,
            "additionalCount": c_add,
            "totalCount": c_total,
            "frequencyPct": round(pct, 2),
            "expectedCount": round(expected_freq, 1),
            "deviation": round(diff, 1),
            "currentGap": curr_gap,
            "avgGap": round(avg_gap, 1),
            "maxGap": max_gap,
            "last20Count": freq_last_20[n],
            "last50Count": freq_last_50[n],
            "hotScore": round(hot_score, 2),
            "status": "HOT" if freq_last_20[n] >= 4 or (curr_gap <= 2 and freq_last_50[n] >= 7) else ("COLD" if curr_gap >= 12 or c_main < expected_freq * 0.75 else "NORMAL")
        })

    # Sort hot numbers and cold numbers
    sorted_by_hot = sorted(number_stats, key=lambda x: x["hotScore"], reverse=True)
    hot_numbers = [item["number"] for item in sorted_by_hot[:10]]
    
    sorted_by_gap = sorted(number_stats, key=lambda x: x["currentGap"], reverse=True)
    cold_numbers = [item["number"] for item in sorted_by_gap[:10]]

    # Theoretical Odd/Even percentages
    # Comb(25, k) * Comb(24, 6-k) / Comb(49, 6)
    def nCr(n, r):
        return math.comb(n, r)
    total_comb = nCr(49, 6)
    odd_even_theoretical = {}
    for k in range(7):
        odds = k
        evens = 6 - k
        count_comb = nCr(25, odds) * nCr(24, evens)
        prob = (count_comb / total_comb) * 100
        odd_even_theoretical[f"{odds}O-{evens}E"] = round(prob, 2)

    odd_even_actual = {}
    for pattern in ["3O-3E", "4O-2E", "2O-4E", "5O-1E", "1O-5E", "6O-0E", "0O-6E"]:
        cnt = odd_even_dist.get(pattern, 0)
        pct = (cnt / total_draws) * 100 if total_draws > 0 else 0
        odd_even_actual[pattern] = {
            "count": cnt,
            "actualPct": round(pct, 2),
            "theoreticalPct": odd_even_theoretical.get(pattern, 0)
        }

    # Sum ranges
    sum_ranges = {
        "< 100": 0,
        "100 - 120": 0,
        "121 - 140": 0,
        "141 - 160": 0,
        "161 - 180": 0,
        "181 - 200": 0,
        "> 200": 0
    }
    for s in sum_distribution:
        if s < 100:
            sum_ranges["< 100"] += 1
        elif s <= 120:
            sum_ranges["100 - 120"] += 1
        elif s <= 140:
            sum_ranges["121 - 140"] += 1
        elif s <= 160:
            sum_ranges["141 - 160"] += 1
        elif s <= 180:
            sum_ranges["161 - 180"] += 1
        elif s <= 200:
            sum_ranges["181 - 200"] += 1
        else:
            sum_ranges["> 200"] += 1

    avg_sum = sum(sum_distribution) / len(sum_distribution) if sum_distribution else 150.0

    return {
        "totalDraws": total_draws,
        "numbers": number_stats,
        "hotNumbers": hot_numbers,
        "coldNumbers": cold_numbers,
        "oddEvenAnalysis": odd_even_actual,
        "highLowAnalysis": {k: {"count": v, "pct": round(v / total_draws * 100, 2)} for k, v in high_low_dist.items()},
        "sumAnalysis": {
            "averageSum": round(avg_sum, 1),
            "theoreticalMean": 150.0,
            "minSum": min(sum_distribution) if sum_distribution else 0,
            "maxSum": max(sum_distribution) if sum_distribution else 0,
            "ranges": sum_ranges
        },
        "consecutiveRatio": {
            "drawsWithConsecutive": consecutive_counts,
            "pct": round(consecutive_counts / total_draws * 100, 2)
        },
        "decadesDistribution": {
            "1-9": decades_dist[0],
            "10-19": decades_dist[1],
            "20-29": decades_dist[2],
            "30-39": decades_dist[3],
            "40-49": decades_dist[4]
        },
        "chiSquare": {
            "statistic": round(chi_square_stat, 2),
            "degreesOfFreedom": 48,
            "interpretation": "Distribution adheres to normal statistical randomness with expected variance."
        }
    }


def analyze_4d(draws):
    """
    Complete statistical analysis of Singapore 4D historical draws.
    draws: list of dicts with keys: drawNumber, drawDate, firstPrize, secondPrize, thirdPrize, starterPrizes (10), consolationPrizes (10)
    """
    total_draws = len(draws)
    if total_draws == 0:
        return {}

    # Counters
    all_numbers_freq = Counter()
    first_prize_freq = Counter()
    second_prize_freq = Counter()
    third_prize_freq = Counter()
    top3_freq = Counter()
    starters_freq = Counter()
    consolations_freq = Counter()

    # Digit position frequencies (0-9)
    # Pos 0: Thousands (first digit), Pos 1: Hundreds, Pos 2: Tens, Pos 3: Units (last digit)
    pos_freq_all = [Counter() for _ in range(4)]
    pos_freq_1st = [Counter() for _ in range(4)]
    
    # Pairs (Front pair: first 2 digits, Mid pair: middle 2, Back pair: last 2 digits)
    front_pairs = Counter()
    back_pairs = Counter()
    mid_pairs = Counter()

    # Pattern categories: Single (ABCD), Double (AABC), Double Pair (AABB), Triple (AAAB), Quad (AAAA)
    pattern_counts = {
        "ABCD": 0, # All different
        "AABC": 0, # 1 pair
        "AABB": 0, # 2 pairs
        "AAAB": 0, # Triple
        "AAAA": 0  # Quad
    }
    
    # Sequence patterns (consecutive)
    sequence_counts = {
        "Ascending_Run": 0,  # e.g. 1234, 4567
        "Descending_Run": 0, # e.g. 4321, 9876
        "Partial_Run": 0,    # 3 consecutive digits e.g. 1238, 7456
        "Non_Sequential": 0
    }

    # Sum of digits distribution
    sum_digits_list = []
    
    # Recency track for 4D numbers
    last_seen_top3 = {}

    for idx, d in enumerate(draws):
        first = str(d["firstPrize"]).zfill(4)
        second = str(d["secondPrize"]).zfill(4)
        third = str(d["thirdPrize"]).zfill(4)
        starters = [str(x).zfill(4) for x in d.get("starterPrizes", [])]
        consolations = [str(x).zfill(4) for x in d.get("consolationPrizes", [])]

        first_prize_freq[first] += 1
        second_prize_freq[second] += 1
        third_prize_freq[third] += 1
        
        top3 = [first, second, third]
        for num in top3:
            top3_freq[num] += 1
            last_seen_top3[num] = idx

        for num in starters:
            starters_freq[num] += 1
        for num in consolations:
            consolations_freq[num] += 1

        # All 23 prizes combined
        all_23 = top3 + starters + consolations
        for num in all_23:
            all_numbers_freq[num] += 1
            
            # Position frequencies
            for pos in range(4):
                digit = int(num[pos])
                pos_freq_all[pos][digit] += 1
                
            # Pairs
            front_pairs[num[:2]] += 1
            mid_pairs[num[1:3]] += 1
            back_pairs[num[2:]] += 1
            
            # Pattern classification
            counts = sorted(Counter(num).values(), reverse=True)
            if counts == [1, 1, 1, 1]:
                pattern_counts["ABCD"] += 1
            elif counts == [2, 1, 1]:
                pattern_counts["AABC"] += 1
            elif counts == [2, 2]:
                pattern_counts["AABB"] += 1
            elif counts == [3, 1]:
                pattern_counts["AAAB"] += 1
            elif counts == [4]:
                pattern_counts["AAAA"] += 1

            # Sequence check
            d_ints = [int(ch) for ch in num]
            is_asc = (d_ints[1] == d_ints[0]+1 and d_ints[2] == d_ints[1]+1 and d_ints[3] == d_ints[2]+1)
            is_desc = (d_ints[1] == d_ints[0]-1 and d_ints[2] == d_ints[1]-1 and d_ints[3] == d_ints[2]-1)
            is_partial = (
                (d_ints[1] == d_ints[0]+1 and d_ints[2] == d_ints[1]+1) or 
                (d_ints[2] == d_ints[1]+1 and d_ints[3] == d_ints[2]+1) or
                (d_ints[1] == d_ints[0]-1 and d_ints[2] == d_ints[1]-1) or 
                (d_ints[2] == d_ints[1]-1 and d_ints[3] == d_ints[2]-1)
            )
            if is_asc:
                sequence_counts["Ascending_Run"] += 1
            elif is_desc:
                sequence_counts["Descending_Run"] += 1
            elif is_partial:
                sequence_counts["Partial_Run"] += 1
            else:
                sequence_counts["Non_Sequential"] += 1

            # Sum of digits
            sum_digits_list.append(sum(d_ints))

        # Position frequencies for 1st Prize specifically
        for pos in range(4):
            pos_freq_1st[pos][int(first[pos])] += 1

    total_4d_drawn = total_draws * 23

    # Pattern theoretical percentages
    pattern_theoretical = {
        "ABCD": 50.40,
        "AABC": 43.20,
        "AABB": 2.70,
        "AAAB": 3.60,
        "AAAA": 0.10
    }
    pattern_stats = {}
    for pat, count in pattern_counts.items():
        pct = (count / total_4d_drawn) * 100 if total_4d_drawn > 0 else 0
        pattern_stats[pat] = {
            "count": count,
            "actualPct": round(pct, 2),
            "theoreticalPct": pattern_theoretical[pat],
            "description": {
                "ABCD": "Single (All 4 digits unique)",
                "AABC": "Double (One pair of identical digits)",
                "AABB": "Double Pair (Two distinct pairs)",
                "AAAB": "Triple (Three identical digits)",
                "AAAA": "Quad (All four digits identical)"
            }[pat]
        }

    # Format digit positions 0-9
    positions_breakdown = {
        "thousandsFirstDigit": {digit: pos_freq_all[0][digit] for digit in range(10)},
        "hundredsSecondDigit": {digit: pos_freq_all[1][digit] for digit in range(10)},
        "tensThirdDigit": {digit: pos_freq_all[2][digit] for digit in range(10)},
        "unitsLastDigit": {digit: pos_freq_all[3][digit] for digit in range(10)}
    }

    first_digit_1st_prize = {digit: pos_freq_1st[0][digit] for digit in range(10)}
    last_digit_1st_prize = {digit: pos_freq_1st[3][digit] for digit in range(10)}

    # Top & least frequent 4D numbers
    most_frequent_overall = [{"number": k, "count": v} for k, v in all_numbers_freq.most_common(15)]
    most_frequent_top3 = [{"number": k, "count": v} for k, v in top3_freq.most_common(10)]
    most_frequent_first_prize = [{"number": k, "count": v} for k, v in first_prize_freq.most_common(10)]
    
    # Top Pairs
    top_front_pairs = [{"pair": k, "count": v} for k, v in front_pairs.most_common(10)]
    top_back_pairs = [{"pair": k, "count": v} for k, v in back_pairs.most_common(10)]
    top_mid_pairs = [{"pair": k, "count": v} for k, v in mid_pairs.most_common(10)]

    return {
        "totalDraws": total_draws,
        "totalPrizesDrawn": total_4d_drawn,
        "patterns": pattern_stats,
        "sequenceAnalysis": {
            k: {"count": v, "pct": round(v / total_4d_drawn * 100, 2)} for k, v in sequence_counts.items()
        },
        "digitPositions": positions_breakdown,
        "firstDigitAnalysis": {
            "distribution": positions_breakdown["thousandsFirstDigit"],
            "firstPrizeFirstDigit": first_digit_1st_prize,
            "mostFrequent": max(positions_breakdown["thousandsFirstDigit"], key=positions_breakdown["thousandsFirstDigit"].get),
            "leastFrequent": min(positions_breakdown["thousandsFirstDigit"], key=positions_breakdown["thousandsFirstDigit"].get)
        },
        "lastDigitAnalysis": {
            "distribution": positions_breakdown["unitsLastDigit"],
            "firstPrizeLastDigit": last_digit_1st_prize,
            "mostFrequent": max(positions_breakdown["unitsLastDigit"], key=positions_breakdown["unitsLastDigit"].get),
            "leastFrequent": min(positions_breakdown["unitsLastDigit"], key=positions_breakdown["unitsLastDigit"].get)
        },
        "pairsAnalysis": {
            "topFrontPairs": top_front_pairs,
            "topBackPairs": top_back_pairs,
            "topMidPairs": top_mid_pairs
        },
        "mostFrequentOverall": most_frequent_overall,
        "mostFrequentTop3": most_frequent_top3,
        "mostFrequentFirstPrize": most_frequent_first_prize,
        "averageDigitSum": round(sum(sum_digits_list) / len(sum_digits_list), 2) if sum_digits_list else 18.0
    }

if __name__ == "__main__":
    # Can run as standalone CLI tool accepting command line args:
    # python analytics.py --type toto --file ../data/toto_seed.json
    # python analytics.py --type 4d --file ../data/fourd_seed.json
    args = sys.argv[1:]
    target_type = "toto"
    filepath = None
    
    for i in range(len(args)):
        if args[i] == "--type" and i + 1 < len(args):
            target_type = args[i+1].lower()
        elif args[i] == "--file" and i + 1 < len(args):
            filepath = args[i+1]

    if not filepath:
        if target_type == "toto":
            filepath = r"d:\github-projets2\toto-ai-master\backend\data\toto_seed.json"
        else:
            filepath = r"d:\github-projets2\toto-ai-master\backend\data\fourd_seed.json"

    with open(filepath, "r", encoding="utf-8") as f:
        data = json.load(f)

    if target_type == "toto":
        result = analyze_toto(data)
    else:
        result = analyze_4d(data)

    print(json.dumps(result))

