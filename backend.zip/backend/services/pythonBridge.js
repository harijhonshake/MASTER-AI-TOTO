const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const AI_DIR = path.join(__dirname, '..', 'ai_engine');

/**
 * Execute Python AI Analytics script
 * @param {'toto' | '4d'} type 
 * @param {Array} drawsData 
 */
function runAnalytics(type, drawsData) {
  return new Promise((resolve, reject) => {
    // Write temporary data to scratch JSON file
    const tempFile = path.join(AI_DIR, `temp_${type}_${Date.now()}.json`);
    try {
      fs.writeFileSync(tempFile, JSON.stringify(drawsData), 'utf-8');
    } catch (err) {
      return reject(err);
    }

    const scriptPath = path.join(AI_DIR, 'analytics.py');
    const py = spawn('python', [scriptPath, '--type', type, '--file', tempFile]);

    let stdout = '';
    let stderr = '';

    py.stdout.on('data', (chunk) => {
      stdout += chunk.toString();
    });

    py.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });

    py.on('close', (code) => {
      // Clean up temp file
      try {
        if (fs.existsSync(tempFile)) {
          fs.unlinkSync(tempFile);
        }
      } catch (e) {}

      if (code !== 0) {
        console.error(`Python analytics error (code ${code}):`, stderr);
        return reject(new Error(stderr || `Python process exited with code ${code}`));
      }

      try {
        const result = JSON.parse(stdout.trim());
        resolve(result);
      } catch (parseErr) {
        reject(new Error(`Failed to parse Python output: ${parseErr.message}\nRaw: ${stdout}`));
      }
    });

    py.on('error', (err) => {
      try {
        if (fs.existsSync(tempFile)) fs.unlinkSync(tempFile);
      } catch (e) {}
      reject(err);
    });
  });
}

/**
 * Execute Python AI Combination Generator
 * @param {'toto' | '4d'} lotteryType 
 * @param {string} mode 
 * @param {object} options 
 */
function runGenerator(lotteryType, mode, options = {}) {
  return new Promise((resolve, reject) => {
    const scriptPath = path.join(AI_DIR, 'generator.py');
    const runnerCode = `
import json
from generator import generate_toto_combination, generate_4d_combination

lottery_type = "${lotteryType}"
mode = "${mode}"
options = ${JSON.stringify(options)}

if lottery_type == "toto":
    res = generate_toto_combination(
        mode=mode,
        hot_numbers=options.get("hotNumbers"),
        cold_numbers=options.get("coldNumbers"),
        favourites=options.get("favourites"),
        count=options.get("count", 1)
    )
else:
    res = generate_4d_combination(
        mode=mode,
        hot_digits=options.get("hotDigits"),
        cold_digits=options.get("coldDigits"),
        favourite=options.get("favourite", ""),
        count=options.get("count", 1)
    )

print(json.dumps(res))
`;

    const py = spawn('python', ['-c', runnerCode], { cwd: AI_DIR });

    let stdout = '';
    let stderr = '';

    py.stdout.on('data', (chunk) => {
      stdout += chunk.toString();
    });

    py.stderr.on('data', (chunk) => {
      stderr += chunk.toString();
    });

    py.on('close', (code) => {
      if (code !== 0) {
        console.error(`Python generator error (code ${code}):`, stderr);
        return reject(new Error(stderr || `Generator exited with code ${code}`));
      }

      try {
        const result = JSON.parse(stdout.trim());
        resolve(result);
      } catch (parseErr) {
        reject(new Error(`Failed to parse generator output: ${parseErr.message}`));
      }
    });

    py.on('error', (err) => {
      reject(err);
    });
  });
}

module.exports = {
  runAnalytics,
  runGenerator
};

