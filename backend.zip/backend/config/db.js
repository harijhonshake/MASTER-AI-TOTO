const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

let isConnectedToMongo = false;

const connectDB = async () => {
  const mongoURI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/toto_ai_master';

  try {
    const conn = await mongoose.connect(mongoURI, {
      serverSelectionTimeoutMS: 2000 // Quick timeout to fallback if mongod not running
    });
    isConnectedToMongo = true;
    console.log(`[Database] MongoDB Connected: ${conn.connection.host}`);
  } catch (err) {
    isConnectedToMongo = false;
    console.warn(`[Database] MongoDB not reachable (${err.message}). Using high-performance local persistent JSON store.`);
  }

  // Ensure data store directory exists
  const storeDir = path.join(__dirname, '..', 'data', 'store');
  if (!fs.existsSync(storeDir)) {
    fs.mkdirSync(storeDir, { recursive: true });
  }

  return isConnectedToMongo;
};

const getMongoStatus = () => isConnectedToMongo;

module.exports = { connectDB, getMongoStatus };

