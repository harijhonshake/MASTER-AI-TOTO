const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');

const STORE_DIR = path.join(__dirname, '..', 'data', 'store');
const SEED_TOTO = path.join(__dirname, '..', 'data', 'toto_seed.json');
const SEED_FOURD = path.join(__dirname, '..', 'data', 'fourd_seed.json');

// Ensure directory exists
if (!fs.existsSync(STORE_DIR)) {
  fs.mkdirSync(STORE_DIR, { recursive: true });
}

class JsonCollection {
  constructor(filename, initialData = []) {
    this.filePath = path.join(STORE_DIR, filename);
    this.data = [];
    this.init(initialData);
  }

  init(initialData) {
    if (fs.existsSync(this.filePath)) {
      try {
        const raw = fs.readFileSync(this.filePath, 'utf-8');
        this.data = JSON.parse(raw);
      } catch (err) {
        console.error(`Error loading ${this.filePath}:`, err);
        this.data = initialData;
        this.save();
      }
    } else {
      this.data = initialData;
      this.save();
    }
  }

  save() {
    try {
      fs.writeFileSync(this.filePath, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (err) {
      console.error(`Error saving ${this.filePath}:`, err);
    }
  }

  find(predicate = () => true) {
    return this.data.filter(predicate);
  }

  findOne(predicate) {
    return this.data.find(predicate);
  }

  findById(id) {
    return this.data.find(item => item._id === id || item.id === id);
  }

  insertOne(doc) {
    const newDoc = {
      _id: doc._id || 'id_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9),
      createdAt: new Date().toISOString(),
      ...doc
    };
    this.data.push(newDoc);
    this.save();
    return newDoc;
  }

  updateOne(predicate, updates) {
    const idx = this.data.findIndex(predicate);
    if (idx !== -1) {
      this.data[idx] = {
        ...this.data[idx],
        ...updates,
        updatedAt: new Date().toISOString()
      };
      this.save();
      return this.data[idx];
    }
    return null;
  }

  deleteOne(predicate) {
    const idx = this.data.findIndex(predicate);
    if (idx !== -1) {
      const removed = this.data.splice(idx, 1)[0];
      this.save();
      return removed;
    }
    return null;
  }

  count(predicate = () => true) {
    return this.data.filter(predicate).length;
  }
}

// Load seed draws
let totoInitial = [];
if (fs.existsSync(SEED_TOTO)) {
  try {
    totoInitial = JSON.parse(fs.readFileSync(SEED_TOTO, 'utf-8'));
  } catch (e) {
    console.error('Failed reading toto seed:', e);
  }
}

let fourdInitial = [];
if (fs.existsSync(SEED_FOURD)) {
  try {
    fourdInitial = JSON.parse(fs.readFileSync(SEED_FOURD, 'utf-8'));
  } catch (e) {
    console.error('Failed reading 4d seed:', e);
  }
}

// Default initial users
const defaultUsers = [
  {
    _id: 'user_sgtamil_01',
    name: 'SgTamil Admin',
    email: 'sgtamil099@.com',
    password: bcrypt.hashSync('Harisg098@', 10),
    role: 'admin',
    createdAt: new Date().toISOString()
  },
  {
    _id: 'user_sgtamil_02',
    name: 'SgTamil Admin',
    email: 'sgtamil099@gmail.com',
    password: bcrypt.hashSync('Harisg098@', 10),
    role: 'admin',
    createdAt: new Date().toISOString()
  },
  {
    _id: 'user_admin_01',
    name: 'TOTO AI Master Admin',
    email: 'admin@totoai.sg',
    password: bcrypt.hashSync('AdminPassword123!', 10),
    role: 'admin',
    createdAt: new Date().toISOString()
  },
  {
    _id: 'user_demo_01',
    name: 'Lucky Explorer',
    email: 'demo@totoai.sg',
    password: bcrypt.hashSync('UserPassword123!', 10),
    role: 'user',
    createdAt: new Date().toISOString()
  }
];

const TotoStore = new JsonCollection('toto_results.json', totoInitial);
const FourDStore = new JsonCollection('fourd_results.json', fourdInitial);
const UserStore = new JsonCollection('users.json', defaultUsers);
const FavouriteStore = new JsonCollection('favourites.json', []);
const AuditStore = new JsonCollection('audit_logs.json', [
  {
    _id: 'audit_01',
    action: 'SYSTEM_INITIALIZATION',
    detail: 'TOTO AI MASTER Database & Seed Data Loaded Successfully',
    timestamp: new Date().toISOString()
  }
]);

module.exports = {
  TotoStore,
  FourDStore,
  UserStore,
  FavouriteStore,
  AuditStore
};

