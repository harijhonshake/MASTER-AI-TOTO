const { TotoStore } = require('../models/store');
const { runAnalytics } = require('../services/pythonBridge');

let cachedTotoStats = null;
let lastStatsDrawCount = 0;

exports.getLatest = async (req, res) => {
  try {
    const all = TotoStore.find().sort((a, b) => b.drawNumber - a.drawNumber);
    if (!all.length) {
      return res.status(404).json({ error: 'No TOTO draws found' });
    }
    const latest = all[0];
    const previous = all[1] || null;

    res.json({
      success: true,
      latest,
      previous,
      totalDraws: all.length
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getAll = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const search = req.query.search ? req.query.search.trim().toLowerCase() : '';

    let list = TotoStore.find();

    if (search) {
      list = list.filter(d => 
        d.drawNumber.toString().includes(search) ||
        (d.drawDate && d.drawDate.includes(search)) ||
        (d.winningNumbers && d.winningNumbers.some(n => n.toString() === search))
      );
    }

    list.sort((a, b) => b.drawNumber - a.drawNumber);

    const total = list.length;
    const startIndex = (page - 1) * limit;
    const paginated = list.slice(startIndex, startIndex + limit);

    res.json({
      success: true,
      data: paginated,
      pagination: {
        total,
        page,
        pages: Math.ceil(total / limit),
        limit
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getStats = async (req, res) => {
  try {
    const all = TotoStore.find().sort((a, b) => a.drawNumber - b.drawNumber);
    if (!all.length) {
      return res.status(404).json({ error: 'No data for analysis' });
    }

    // Use cached analytics if draw count hasn't changed
    if (cachedTotoStats && lastStatsDrawCount === all.length) {
      return res.json({ success: true, ...cachedTotoStats });
    }

    const stats = await runAnalytics('toto', all);
    cachedTotoStats = stats;
    lastStatsDrawCount = all.length;

    res.json({
      success: true,
      ...stats
    });
  } catch (err) {
    console.error('TOTO stats error:', err);
    res.status(500).json({ error: 'Failed to compute AI statistics: ' + err.message });
  }
};

exports.checkNumbers = async (req, res) => {
  try {
    const { numbers } = req.body; // array of 6 numbers
    if (!Array.isArray(numbers) || numbers.length !== 6) {
      return res.status(400).json({ error: 'Please provide exactly 6 numbers from 1 to 49.' });
    }

    const cleanNumbers = numbers.map(Number).sort((a, b) => a - b);
    const valid = cleanNumbers.every(n => Number.isInteger(n) && n >= 1 && n <= 49);
    const unique = new Set(cleanNumbers).size === 6;

    if (!valid || !unique) {
      return res.status(400).json({ error: 'Numbers must be 6 unique integers between 1 and 49.' });
    }

    const all = TotoStore.find().sort((a, b) => b.drawNumber - a.drawNumber);
    const matches = [];

    all.forEach(draw => {
      const winSet = new Set(draw.winningNumbers);
      const matchedNums = cleanNumbers.filter(n => winSet.has(n));
      const hasAdditional = draw.additionalNumber && cleanNumbers.includes(draw.additionalNumber);

      let prizeGroup = null;
      if (matchedNums.length === 6) prizeGroup = 'Group 1 (Jackpot)';
      else if (matchedNums.length === 5 && hasAdditional) prizeGroup = 'Group 2';
      else if (matchedNums.length === 5) prizeGroup = 'Group 3';
      else if (matchedNums.length === 4 && hasAdditional) prizeGroup = 'Group 4';
      else if (matchedNums.length === 4) prizeGroup = 'Group 5';
      else if (matchedNums.length === 3 && hasAdditional) prizeGroup = 'Group 6';
      else if (matchedNums.length === 3) prizeGroup = 'Group 7';

      if (matchedNums.length >= 3) {
        matches.push({
          drawNumber: draw.drawNumber,
          drawDate: draw.drawDate,
          matchedCount: matchedNums.length,
          matchedNumbers: matchedNums,
          hasAdditional,
          additionalNumber: draw.additionalNumber,
          prizeGroup
        });
      }
    });

    res.json({
      success: true,
      checkedNumbers: cleanNumbers,
      totalCheckedDraws: all.length,
      matchesCount: matches.length,
      matches
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

