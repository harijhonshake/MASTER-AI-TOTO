const { FourDStore } = require('../models/store');
const { runAnalytics } = require('../services/pythonBridge');

let cachedFourDStats = null;
let last4DStatsCount = 0;

exports.getLatest = async (req, res) => {
  try {
    const all = FourDStore.find().sort((a, b) => b.drawNumber - a.drawNumber);
    if (!all.length) {
      return res.status(404).json({ error: 'No 4D draws found' });
    }
    const latest = all[0];
    const previous = all[1] || null;

    res.json({
      success: true,
      latest,
      previous,
      totalDraws: all.length
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getAll = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 15;
    const search = req.query.search ? req.query.search.trim().toLowerCase() : '';

    let list = FourDStore.find();

    if (search) {
      list = list.filter(d => 
        d.drawNumber.toString().includes(search) ||
        (d.drawDate && d.drawDate.includes(search)) ||
        d.firstPrize === search ||
        d.secondPrize === search ||
        d.thirdPrize === search ||
        (d.starterPrizes && d.starterPrizes.includes(search)) ||
        (d.consolationPrizes && d.consolationPrizes.includes(search))
      );
    }

    list.sort((a, b) => b.drawNumber - a.drawNumber);

    const total = list.length;
    const startIndex = (page - 1) * limit;
    const paginated = list.slice(startIndex, startIndex + limit);

    res.json({
      success: true,
      data: paginated,
      pagination: {
        total,
        page,
        pages: Math.ceil(total / limit),
        limit
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getStats = async (req, res) => {
  try {
    const all = FourDStore.find().sort((a, b) => a.drawNumber - b.drawNumber);
    if (!all.length) {
      return res.status(404).json({ error: 'No 4D data for analysis' });
    }

    if (cachedFourDStats && last4DStatsCount === all.length) {
      return res.json({ success: true, ...cachedFourDStats });
    }

    const stats = await runAnalytics('4d', all);
    cachedFourDStats = stats;
    last4DStatsCount = all.length;

    res.json({
      success: true,
      ...stats
    });
  } catch (err) {
    console.error('4D stats error:', err);
    res.status(500).json({ error: 'Failed to compute 4D statistics: ' + err.message });
  }
};

exports.checkNumber = async (req, res) => {
  try {
    const { number } = req.body;
    if (!number || typeof number !== 'string' || !/^\d{4}$/.test(number.trim())) {
      return res.status(400).json({ error: 'Please provide a valid 4-digit number (0000-9999).' });
    }

    const target = number.trim();
    const all = FourDStore.find().sort((a, b) => b.drawNumber - a.drawNumber);
    const hits = [];

    all.forEach(draw => {
      let prizeType = null;
      if (draw.firstPrize === target) prizeType = '1st Prize';
      else if (draw.secondPrize === target) prizeType = '2nd Prize';
      else if (draw.thirdPrize === target) prizeType = '3rd Prize';
      else if (draw.starterPrizes && draw.starterPrizes.includes(target)) prizeType = 'Starter Prize';
      else if (draw.consolationPrizes && draw.consolationPrizes.includes(target)) prizeType = 'Consolation Prize';

      if (prizeType) {
        hits.push({
          drawNumber: draw.drawNumber,
          drawDate: draw.drawDate,
          prizeType
        });
      }
    });

    res.json({
      success: true,
      number: target,
      totalCheckedDraws: all.length,
      hitCount: hits.length,
      history: hits
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

