const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { UserStore, FavouriteStore } = require('../models/store');

const JWT_SECRET = process.env.JWT_SECRET || 'toto_ai_master_jwt_secret_key_2026';

const generateToken = (user) => {
  return jwt.sign(
    { id: user._id, email: user.email, role: user.role, name: user.name },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
};

// Middleware for authentication
const authenticate = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required. No token provided.' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired authentication token.' });
  }
};

// Middleware for admin access
const requireAdmin = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied. Administrator privileges required.' });
  }
  next();
};

exports.register = async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email, and password are required.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const existing = UserStore.findOne(u => u.email === cleanEmail);
    if (existing) {
      return res.status(400).json({ error: 'An account with this email already exists.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = UserStore.insertOne({
      name: name.trim(),
      email: cleanEmail,
      password: hashedPassword,
      role: 'user'
    });

    const token = generateToken(newUser);

    res.status(201).json({
      success: true,
      token,
      user: {
        id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        role: newUser.role
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const user = UserStore.findOne(u => u.email === cleanEmail);
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const token = generateToken(user);

    res.json({
      success: true,
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getMe = async (req, res) => {
  try {
    const user = UserStore.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ error: 'User not found.' });
    }

    res.json({
      success: true,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        createdAt: user.createdAt
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getFavourites = async (req, res) => {
  try {
    const userId = req.user.id;
    const favs = FavouriteStore.find(f => f.userId === userId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    res.json({
      success: true,
      favourites: favs
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.addFavourite = async (req, res) => {
  try {
    const userId = req.user.id;
    const { type, numbers, label, notes } = req.body;

    if (!type || !['toto', '4d'].includes(type)) {
      return res.status(400).json({ error: 'Valid type (toto or 4d) is required.' });
    }

    if (!numbers) {
      return res.status(400).json({ error: 'Numbers are required.' });
    }

    const favItem = FavouriteStore.insertOne({
      userId,
      type,
      numbers,
      label: label || (type === 'toto' ? 'My TOTO Pick' : 'My 4D Lucky'),
      notes: notes || ''
    });

    res.status(201).json({
      success: true,
      favourite: favItem
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteFavourite = async (req, res) => {
  try {
    const userId = req.user.id;
    const { id } = req.params;

    const fav = FavouriteStore.findOne(f => f._id === id && f.userId === userId);
    if (!fav) {
      return res.status(404).json({ error: 'Favourite not found or access denied.' });
    }

    FavouriteStore.deleteOne(f => f._id === id);

    res.json({
      success: true,
      message: 'Favourite deleted successfully.'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = {
  ...exports,
  authenticate,
  requireAdmin
};

