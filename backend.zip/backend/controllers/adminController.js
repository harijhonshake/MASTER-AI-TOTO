const { TotoStore, FourDStore, UserStore, AuditStore } = require('../models/store');
const syncService = require('../services/syncService');

// 1. TOTO Management
exports.createTotoDraw = async (req, res) => {
  try {
    const { drawNumber, drawDate, winningNumbers, additionalNumber, jackpot, isCascade, venue } = req.body;

    if (!drawNumber || !drawDate || !winningNumbers || additionalNumber === undefined) {
      return res.status(400).json({ error: 'drawNumber, drawDate, winningNumbers (6 nums), and additionalNumber are required.' });
    }

    const num = parseInt(drawNumber);
    if (TotoStore.findOne(d => d.drawNumber === num)) {
      return res.status(400).json({ error: `Draw #${num} already exists in database.` });
    }

    const cleanWinning = winningNumbers.map(Number).sort((a, b) => a - b);
    const valid = cleanWinning.length === 6 && cleanWinning.every(n => n >= 1 && n <= 49);
    const unique = new Set(cleanWinning).size === 6;
    const addNum = parseInt(additionalNumber);

    if (!valid || !unique || addNum < 1 || addNum > 49 || cleanWinning.includes(addNum)) {
      return res.status(400).json({ error: 'Winning numbers must be 6 unique integers 1-49, and additional number must be 1-49 and distinct from winning numbers.' });
    }

    const dateObj = new Date(drawDate);
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const newDraw = TotoStore.insertOne({
      drawNumber: num,
      drawDate,
      drawDay: days[dateObj.getDay()] || 'Monday',
      winningNumbers: cleanWinning,
      additionalNumber: addNum,
      jackpot: parseInt(jackpot) || 1000000,
      isCascade: Boolean(isCascade),
      group1Winners: 0,
      group2Winners: 0,
      group1Prize: 0,
      venue: venue || 'Singapore Pools Building, 210 Middle Road',
      verified: true,
      verifiedBy: req.user.email
    });

    AuditStore.insertOne({
      action: 'ADMIN_CREATE_TOTO',
      detail: `Created TOTO draw #${num} by ${req.user.email}`,
      timestamp: new Date().toISOString()
    });

    res.status(201).json({ success: true, draw: newDraw });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateTotoDraw = async (req, res) => {
  try {
    const { id } = req.params;
    const existing = TotoStore.findOne(d => d._id === id || d.drawNumber === parseInt(id));
    if (!existing) {
      return res.status(404).json({ error: 'TOTO draw not found' });
    }

    const updates = { ...req.body };
    if (updates.winningNumbers) {
      updates.winningNumbers = updates.winningNumbers.map(Number).sort((a, b) => a - b);
    }
    if (updates.additionalNumber) {
      updates.additionalNumber = parseInt(updates.additionalNumber);
    }

    const updated = TotoStore.updateOne(d => d._id === existing._id, updates);

    AuditStore.insertOne({
      action: 'ADMIN_UPDATE_TOTO',
      detail: `Updated TOTO draw #${existing.drawNumber} by ${req.user.email}`,
      timestamp: new Date().toISOString()
    });

    res.json({ success: true, draw: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteTotoDraw = async (req, res) => {
  try {
    const { id } = req.params;
    const existing = TotoStore.findOne(d => d._id === id || d.drawNumber === parseInt(id));
    if (!existing) {
      return res.status(404).json({ error: 'TOTO draw not found' });
    }

    TotoStore.deleteOne(d => d._id === existing._id);

    AuditStore.insertOne({
      action: 'ADMIN_DELETE_TOTO',
      detail: `Deleted TOTO draw #${existing.drawNumber} by ${req.user.email}`,
      timestamp: new Date().toISOString()
    });

    res.json({ success: true, message: `Draw #${existing.drawNumber} deleted successfully.` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 2. 4D Management
exports.createFourDDraw = async (req, res) => {
  try {
    const { drawNumber, drawDate, firstPrize, secondPrize, thirdPrize, starterPrizes, consolationPrizes, venue } = req.body;

    if (!drawNumber || !drawDate || !firstPrize || !secondPrize || !thirdPrize) {
      return res.status(400).json({ error: 'drawNumber, drawDate, firstPrize, secondPrize, thirdPrize are required.' });
    }

    const num = parseInt(drawNumber);
    if (FourDStore.findOne(d => d.drawNumber === num)) {
      return res.status(400).json({ error: `4D Draw #${num} already exists in database.` });
    }

    const format4 = (x) => String(x).padStart(4, '0');
    const p1 = format4(firstPrize);
    const p2 = format4(secondPrize);
    const p3 = format4(thirdPrize);

    const starters = (starterPrizes || []).map(format4);
    const consolations = (consolationPrizes || []).map(format4);

    const dateObj = new Date(drawDate);
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const newDraw = FourDStore.insertOne({
      drawNumber: num,
      drawDate,
      drawDay: days[dateObj.getDay()] || 'Wednesday',
      firstPrize: p1,
      secondPrize: p2,
      thirdPrize: p3,
      starterPrizes: starters,
      consolationPrizes: consolations,
      venue: venue || 'Singapore Pools Building, 210 Middle Road',
      verified: true,
      verifiedBy: req.user.email
    });

    AuditStore.insertOne({
      action: 'ADMIN_CREATE_4D',
      detail: `Created 4D draw #${num} by ${req.user.email}`,
      timestamp: new Date().toISOString()
    });

    res.status(201).json({ success: true, draw: newDraw });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateFourDDraw = async (req, res) => {
  try {
    const { id } = req.params;
    const existing = FourDStore.findOne(d => d._id === id || d.drawNumber === parseInt(id));
    if (!existing) {
      return res.status(404).json({ error: '4D draw not found' });
    }

    const updates = { ...req.body };
    const updated = FourDStore.updateOne(d => d._id === existing._id, updates);

    AuditStore.insertOne({
      action: 'ADMIN_UPDATE_4D',
      detail: `Updated 4D draw #${existing.drawNumber} by ${req.user.email}`,
      timestamp: new Date().toISOString()
    });

    res.json({ success: true, draw: updated });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteFourDDraw = async (req, res) => {
  try {
    const { id } = req.params;
    const existing = FourDStore.findOne(d => d._id === id || d.drawNumber === parseInt(id));
    if (!existing) {
      return res.status(404).json({ error: '4D draw not found' });
    }

    FourDStore.deleteOne(d => d._id === existing._id);

    AuditStore.insertOne({
      action: 'ADMIN_DELETE_4D',
      detail: `Deleted 4D draw #${existing.drawNumber} by ${req.user.email}`,
      timestamp: new Date().toISOString()
    });

    res.json({ success: true, message: `4D Draw #${existing.drawNumber} deleted successfully.` });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 3. Import Historical Data (Bulk JSON)
exports.importData = async (req, res) => {
  try {
    const { type, records } = req.body;
    if (!type || !Array.isArray(records)) {
      return res.status(400).json({ error: 'Type (toto/4d) and records array are required.' });
    }

    let imported = 0;
    let skipped = 0;

    if (type === 'toto') {
      records.forEach(rec => {
        if (!TotoStore.findOne(d => d.drawNumber === rec.drawNumber)) {
          TotoStore.insertOne(rec);
          imported++;
        } else {
          skipped++;
        }
      });
    } else if (type === '4d') {
      records.forEach(rec => {
        if (!FourDStore.findOne(d => d.drawNumber === rec.drawNumber)) {
          FourDStore.insertOne(rec);
          imported++;
        } else {
          skipped++;
        }
      });
    }

    AuditStore.insertOne({
      action: 'ADMIN_IMPORT_DATA',
      detail: `Imported ${imported} records (${skipped} skipped) for ${type} by ${req.user.email}`,
      timestamp: new Date().toISOString()
    });

    res.json({
      success: true,
      imported,
      skipped,
      message: `Successfully processed ${records.length} records.`
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 4. Trigger Automatic Results Sync
exports.triggerSync = async (req, res) => {
  try {
    const result = await syncService.syncAll();
    res.json({ success: true, result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 5. User Management
exports.getUsers = async (req, res) => {
  try {
    const users = UserStore.find().map(u => ({
      id: u._id,
      name: u.name,
      email: u.email,
      role: u.role,
      createdAt: u.createdAt
    }));
    res.json({ success: true, users });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.updateUserRole = async (req, res) => {
  try {
    const { id } = req.params;
    const { role } = req.body;
    if (!['user', 'admin'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role. Must be user or admin.' });
    }

    const updated = UserStore.updateOne(u => u._id === id, { role });
    if (!updated) {
      return res.status(404).json({ error: 'User not found' });
    }

    AuditStore.insertOne({
      action: 'ADMIN_UPDATE_USER_ROLE',
      detail: `Updated user ${updated.email} role to ${role} by ${req.user.email}`,
      timestamp: new Date().toISOString()
    });

    res.json({ success: true, user: { id: updated._id, name: updated.name, email: updated.email, role: updated.role } });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// 6. Application Analytics & Audit Logs
exports.getSystemAnalytics = async (req, res) => {
  try {
    const totoCount = TotoStore.count();
    const fourDCount = FourDStore.count();
    const userCount = UserStore.count();
    const auditLogs = AuditStore.find().reverse().slice(0, 30);

    const memoryUsage = process.memoryUsage();

    res.json({
      success: true,
      stats: {
        totalTotoDraws: totoCount,
        totalFourDDraws: fourDCount,
        totalUsers: userCount,
        uptimeSeconds: Math.floor(process.uptime()),
        memoryRssMb: Math.round(memoryUsage.rss / 1024 / 1024),
        nodeVersion: process.version,
        lastSync: syncService.lastSyncTime || 'Pending first trigger'
      },
      auditLogs
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

