require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { connectDB } = require('./config/db');
const syncService = require('./services/syncService');

const totoRoutes = require('./routes/totoRoutes');
const fourDRoutes = require('./routes/fourDRoutes');
const aiRoutes = require('./routes/aiRoutes');
const authRoutes = require('./routes/authRoutes');
const adminRoutes = require('./routes/adminRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: '*',
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));
app.use(express.json({ limit: '10mb' }));

// Healthcheck
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ONLINE',
    app: 'TOTO AI MASTER - Singapore TOTO & 4D Analysis Platform',
    timestamp: new Date().toISOString(),
    responsibleGaming: 'Lottery results are independent random events. Play responsibly. 18+'
  });
});

// API Routes
app.use('/api/toto', totoRoutes);
app.use('/api/fourd', fourDRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/admin', adminRoutes);

// Serve static frontend in production if built
const frontendDist = path.join(__dirname, '..', 'frontend', 'dist');
if (fs.existsSync(frontendDist)) {
  app.use(express.static(frontendDist));
  app.get('*', (req, res) => {
    if (!req.path.startsWith('/api')) {
      res.sendFile(path.join(frontendDist, 'index.html'));
    }
  });
}

// 404 Handler for API
app.use('/api/*', (req, res) => {
  res.status(404).json({ error: `API endpoint not found: ${req.method} ${req.originalUrl}` });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('[ServerError]', err);
  res.status(err.status || 500).json({
    error: err.message || 'Internal Server Error'
  });
});

// Boot server
async function startServer() {
  await connectDB();

  // Start background auto-sync
  syncService.startAutoSync();

  const server = app.listen(PORT, () => {
    console.log('====================================================');
    console.log('TOTO AI MASTER running on http://localhost:' + PORT);
    console.log('Healthcheck: http://localhost:' + PORT + '/api/health');
    console.log('TOTO API:    http://localhost:' + PORT + '/api/toto/latest');
    console.log('4D API:      http://localhost:' + PORT + '/api/fourd/latest');
    console.log('Admin:       http://localhost:' + PORT);
    console.log('====================================================');
  });

  server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
      console.error('[Server] Port ' + PORT + ' in use. Retrying in 3s...');
      setTimeout(() => {
        server.close();
        server.listen(PORT);
      }, 3000);
    } else {
      console.error('[Server] Fatal error:', err);
      process.exit(1);
    }
  });

  // Graceful shutdown
  process.on('SIGTERM', () => { server.close(() => process.exit(0)); });
  process.on('SIGINT',  () => { server.close(() => process.exit(0)); });
}

startServer();

